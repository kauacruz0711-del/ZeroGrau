
import React from 'react'
import { NavLink } from 'react-router-dom'
import {Home, BookOpen, Brain, Gamepad2, Shield, User} from 'lucide-react'

const Navigation = () => {
  const navItems = [
    { icon: Home, label: 'Início', path: '/' },
    { icon: BookOpen, label: 'Educação', path: '/education' },
    { icon: Brain, label: 'Quiz', path: '/quiz' },
    { icon: Gamepad2, label: 'Jogos', path: '/games' },
    { icon: Shield, label: 'Prevenção', path: '/prevention' },
    { icon: User, label: 'Conta', path: '/account' }
  ]

  return (
    <>
      {/* Main navigation */}
      <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 px-1 py-2 z-50">
        <div className="flex justify-around">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex flex-col items-center py-2 px-2 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-100 text-indigo-600'
                    : 'text-gray-600 hover:text-indigo-600 hover:bg-gray-50'
                }`
              }
            >
              <item.icon size={18} />
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>

      {/* Spacer for bottom navigation */}
      <div className="h-20"></div>
    </>
  )
}

export default Navigation
