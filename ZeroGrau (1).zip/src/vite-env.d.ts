
/// <reference types="vite/client" />

