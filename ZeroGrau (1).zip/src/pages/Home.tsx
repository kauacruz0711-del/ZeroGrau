
import React from 'react'
import {BookOpen, Brain, Gamepad2, Shield, GraduationCap, Heart} from 'lucide-react'
import { Link } from 'react-router-dom'

const Home = () => {
  const features = [
    {
      icon: BookOpen,
      title: "Educação",
      description: "Aprenda sobre os efeitos das substâncias",
      path: "/education",
      color: "bg-blue-500"
    },
    {
      icon: Brain,
      title: "Quiz",
      description: "Teste seus conhecimentos",
      path: "/quiz",
      color: "bg-purple-500"
    },
    {
      icon: Gamepad2,
      title: "Jogos",
      description: "Aprenda de forma divertida",
      path: "/games",
      color: "bg-green-500"
    },
    {
      icon: Shield,
      title: "Prevenção",
      description: "Dicas de prevenção e ajuda",
      path: "/prevention",
      color: "bg-red-500"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 text-white p-8">
        <div className="text-center">
          <div className="bg-white/20 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <GraduationCap size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold mb-2">ZeroGrau</h1>
          <p className="text-lg opacity-90">Educação e Prevenção</p>
        </div>
      </div>

      {/* Features Grid */}
      <div className="p-6">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">
          Explore o App
        </h2>
        
        <div className="grid grid-cols-2 gap-4">
          {features.map((feature) => (
            <Link key={feature.title} to={feature.path}>
              <div className={`${feature.color} rounded-2xl p-6 text-white shadow-lg hover:shadow-xl transition-shadow`}>
                <feature.icon size={32} className="mb-3" />
                <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-sm opacity-90">{feature.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Mission Statement */}
      <div className="px-6 py-6">
        <div className="bg-gradient-to-r from-pink-50 via-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-100">
          <div className="flex items-center gap-3 mb-4">
            <Heart className="text-red-500" size={24} />
            <h2 className="text-xl font-bold text-gray-800">Nossa Missão</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            Educar jovens sobre os riscos do álcool e drogas através de conteúdo 
            interativo, científico e acessível. Promovemos escolhas conscientes 
            e um futuro mais saudável.
          </p>
        </div>
      </div>

      {/* Statistics */}
      <div className="px-6 pb-6">
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-6 border border-amber-200">
          <h3 className="text-lg font-bold text-amber-800 mb-4 text-center">
            📊 Dados que Importam
          </h3>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="p-3 bg-white/70 rounded-lg">
              <div className="text-2xl font-bold text-amber-700">27%</div>
              <div className="text-sm text-amber-600">dos jovens usam álcool</div>
            </div>
            <div className="p-3 bg-white/70 rounded-lg">
              <div className="text-2xl font-bold text-amber-700">9%</div>
              <div className="text-sm text-amber-600">usam drogas ilícitas</div>
            </div>
          </div>
          <p className="text-xs text-amber-600 text-center mt-4">
            *Dados IBGE 2023 - Faixa etária 14-18 anos
          </p>
        </div>
      </div>
    </div>
  )
}

export default Home
