
import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {ArrowLeft, Gamepad2, Brain, Zap, RotateCcw, Star} from 'lucide-react'
import { Link } from 'react-router-dom'
import toast from 'react-hot-toast'

const Games = () => {
  const [selectedGame, setSelectedGame] = useState<string | null>(null)
  const [memoryCards, setMemoryCards] = useState<any[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedCards, setMatchedCards] = useState<number[]>([])
  const [moves, setMoves] = useState(0)
  const [gameWon, setGameWon] = useState(false)
  const [quickQuizScore, setQuickQuizScore] = useState(0)
  const [currentQuickQuestion, setCurrentQuickQuestion] = useState(0)

  const cardPairs = [
    { id: 1, content: '🧠', match: 'Cérebro' },
    { id: 2, content: 'Cérebro', match: '🧠' },
    { id: 3, content: '❤️', match: 'Coração' },
    { id: 4, content: 'Coração', match: '❤️' },
    { id: 5, content: '🫁', match: 'Pulmões' },
    { id: 6, content: 'Pulmões', match: '🫁' },
    { id: 7, content: '🍺', match: 'Álcool' },
    { id: 8, content: 'Álcool', match: '🍺' },
  ]

  const quickQuizQuestions = [
    { question: "O álcool é uma droga?", answer: true },
    { question: "Fumar maconha não causa dependência?", answer: false },
    { question: "O cérebro adolescente é mais vulnerável às drogas?", answer: true },
    { question: "Bebidas energéticas com álcool são seguras?", answer: false },
    { question: "É possível se divertir sem usar drogas?", answer: true },
  ]

  useEffect(() => {
    if (selectedGame === 'memory') {
      initializeMemoryGame()
    }
  }, [selectedGame])

  useEffect(() => {
    if (flippedCards.length === 2) {
      const [first, second] = flippedCards
      if (memoryCards[first]?.match === memoryCards[second]?.content) {
        setMatchedCards([...matchedCards, first, second])
        setFlippedCards([])
        toast.success('Par encontrado! 🎉')
        
        if (matchedCards.length + 2 === memoryCards.length) {
          setGameWon(true)
          toast.success('Parabéns! Você venceu! 🏆')
        }
      } else {
        setTimeout(() => setFlippedCards([]), 1000)
      }
      setMoves(moves + 1)
    }
  }, [flippedCards, memoryCards, matchedCards, moves])

  const initializeMemoryGame = () => {
    const shuffled = [...cardPairs].sort(() => Math.random() - 0.5)
    setMemoryCards(shuffled)
    setFlippedCards([])
    setMatchedCards([])
    setMoves(0)
    setGameWon(false)
  }

  const flipCard = (index: number) => {
    if (flippedCards.length < 2 && !flippedCards.includes(index) && !matchedCards.includes(index)) {
      setFlippedCards([...flippedCards, index])
    }
  }

  const handleQuickQuizAnswer = (answer: boolean) => {
    const correct = quickQuizQuestions[currentQuickQuestion].answer === answer
    if (correct) {
      setQuickQuizScore(quickQuizScore + 1)
      toast.success('Correto! 🎉')
    } else {
      toast.error('Incorreto! 😔')
    }

    if (currentQuickQuestion < quickQuizQuestions.length - 1) {
      setCurrentQuickQuestion(currentQuickQuestion + 1)
    } else {
      toast.success(`Quiz concluído! Pontuação: ${quickQuizScore + (correct ? 1 : 0)}/${quickQuizQuestions.length}`)
    }
  }

  const resetQuickQuiz = () => {
    setCurrentQuickQuestion(0)
    setQuickQuizScore(0)
  }

  const games = [
    {
      id: 'memory',
      title: 'Jogo da Memória',
      description: 'Encontre os pares relacionados às drogas e seus efeitos',
      icon: <Brain className="w-8 h-8" />,
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: 'quickquiz',
      title: 'Quiz Rápido',
      description: 'Verdadeiro ou falso sobre drogas',
      icon: <Zap className="w-8 h-8" />,
      color: 'from-yellow-500 to-orange-500'
    }
  ]

  if (selectedGame === 'memory') {
    return (
      <div className="p-6 pb-24">
        <div className="flex items-center mb-6">
          <button onClick={() => setSelectedGame(null)}>
            <ArrowLeft className="w-6 h-6 text-gray-600 mr-4" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Jogo da Memória</h1>
        </div>

        <div className="flex justify-between items-center mb-6">
          <p className="text-sm text-gray-600">Movimentos: {moves}</p>
          <button
            onClick={initializeMemoryGame}
            className="flex items-center px-3 py-1 bg-blue-100 text-blue-600 rounded-lg text-sm"
          >
            <RotateCcw className="w-4 h-4 mr-1" />
            Reiniciar
          </button>
        </div>

        {gameWon && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4 rounded-2xl mb-6 text-center"
          >
            <Star className="w-8 h-8 mx-auto mb-2" />
            <h3 className="font-bold">Parabéns!</h3>
            <p className="text-sm">Você completou o jogo em {moves} movimentos!</p>
          </motion.div>
        )}

        <div className="grid grid-cols-4 gap-3">
          {memoryCards.map((card, index) => (
            <motion.button
              key={index}
              whileTap={{ scale: 0.95 }}
              onClick={() => flipCard(index)}
              className="aspect-square bg-white rounded-xl shadow-lg flex items-center justify-center text-lg font-bold relative overflow-hidden"
            >
              <AnimatePresence mode="wait">
                {flippedCards.includes(index) || matchedCards.includes(index) ? (
                  <motion.div
                    initial={{ rotateY: 90 }}
                    animate={{ rotateY: 0 }}
                    exit={{ rotateY: 90 }}
                    className="w-full h-full flex items-center justify-center"
                  >
                    {card.content.length === 2 ? (
                      <span className="text-2xl">{card.content}</span>
                    ) : (
                      <span className="text-xs text-center px-1">{card.content}</span>
                    )}
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ rotateY: 0 }}
                    animate={{ rotateY: 0 }}
                    className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center"
                  >
                    <span className="text-white text-xl">?</span>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          ))}
        </div>
      </div>
    )
  }

  if (selectedGame === 'quickquiz') {
    return (
      <div className="p-6 pb-24">
        <div className="flex items-center mb-6">
          <button onClick={() => setSelectedGame(null)}>
            <ArrowLeft className="w-6 h-6 text-gray-600 mr-4" />
          </button>
          <h1 className="text-xl font-bold text-gray-800">Quiz Rápido</h1>
        </div>

        <div className="flex justify-between items-center mb-6">
          <p className="text-sm text-gray-600">
            Pergunta {currentQuickQuestion + 1} de {quickQuizQuestions.length}
          </p>
          <p className="text-sm font-semibold">Pontuação: {quickQuizScore}</p>
        </div>

        {currentQuickQuestion < quickQuizQuestions.length ? (
          <motion.div
            key={currentQuickQuestion}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-6 shadow-lg mb-6"
          >
            <h2 className="text-lg font-bold text-gray-800 mb-6 text-center">
              {quickQuizQuestions[currentQuickQuestion].question}
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleQuickQuizAnswer(true)}
                className="bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-bold text-lg"
              >
                ✓ VERDADEIRO
              </motion.button>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleQuickQuizAnswer(false)}
                className="bg-gradient-to-r from-red-500 to-red-600 text-white py-4 rounded-xl font-bold text-lg"
              >
                ✗ FALSO
              </motion.button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="text-center"
          >
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white p-6 rounded-2xl mb-6">
              <Star className="w-12 h-12 mx-auto mb-3" />
              <h3 className="text-xl font-bold mb-2">Quiz Concluído!</h3>
              <p className="text-lg">
                {quickQuizScore} de {quickQuizQuestions.length} corretas
              </p>
            </div>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={resetQuickQuiz}
              className="bg-blue-500 text-white px-6 py-3 rounded-xl font-semibold flex items-center mx-auto"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Jogar Novamente
            </motion.button>
          </motion.div>
        )}
      </div>
    )
  }

  return (
    <div className="p-6 pb-24">
      <div className="flex items-center mb-6">
        <Link to="/">
          <ArrowLeft className="w-6 h-6 text-gray-600 mr-4" />
        </Link>
        <h1 className="text-xl font-bold text-gray-800">Jogos Educativos</h1>
      </div>

      <div className="space-y-4">
        {games.map((game) => (
          <motion.button
            key={game.id}
            whileTap={{ scale: 0.98 }}
            onClick={() => setSelectedGame(game.id)}
            className={`w-full bg-gradient-to-r ${game.color} p-6 rounded-2xl text-white shadow-lg`}
          >
            <div className="flex items-center">
              <div className="mr-4">{game.icon}</div>
              <div className="text-left">
                <h3 className="font-bold text-lg mb-1">{game.title}</h3>
                <p className="text-sm opacity-90">{game.description}</p>
              </div>
              <Gamepad2 className="w-6 h-6 ml-auto" />
            </div>
          </motion.button>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="mt-8 bg-blue-50 border border-blue-200 rounded-2xl p-4"
      >
        <h3 className="font-bold text-blue-800 mb-2">🎮 Dica dos Jogos</h3>
        <p className="text-sm text-blue-700">
          Os jogos são uma forma divertida de aprender! Quanto mais você joga, mais conhecimento adquire sobre prevenção ao uso de drogas.
        </p>
      </motion.div>
    </div>
  )
}

export default Games
