
import React from 'react'
import {User, Mail, Calendar, Trophy, Target, LogOut, Shield} from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import toast from 'react-hot-toast'

const Account = () => {
  const { user, signOut } = useAuth()

  const handleLogout = async () => {
    try {
      await signOut()
      toast.success('Logout realizado com sucesso!', {
        position: 'top-center',
        style: {
          background: '#10b981',
          color: 'white',
          fontWeight: 'bold',
          borderRadius: '12px'
        }
      })
    } catch (error) {
      toast.error('Erro ao fazer logout.', {
        position: 'top-center'
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    })
  }

  // Dados simulados de progresso (você pode conectar com dados reais)
  const userStats = {
    quizzesCompleted: 12,
    educationProgress: 85,
    gamesPlayed: 8,
    daysActive: 15
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 pb-24 pt-16">
      <div className="max-w-md mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <User size={40} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Minha Conta</h1>
          <p className="text-gray-600">Gerencie suas informações pessoais</p>
        </div>

        {/* Informações do Usuário */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <User size={20} className="text-indigo-600" />
            Informações Pessoais
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <User size={18} className="text-gray-600" />
              <div>
                <p className="text-sm text-gray-600">Nome</p>
                <p className="font-medium text-gray-800">{user?.name || 'Usuário'}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Mail size={18} className="text-gray-600" />
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="font-medium text-gray-800">{user?.email}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar size={18} className="text-gray-600" />
              <div>
                <p className="text-sm text-gray-600">Membro desde</p>
                <p className="font-medium text-gray-800">
                  {user?.createdAt ? formatDate(user.createdAt) : 'Data não disponível'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Estatísticas */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Trophy size={20} className="text-indigo-600" />
            Suas Estatísticas
          </h2>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg">
              <div className="text-2xl font-bold text-indigo-600">{userStats.quizzesCompleted}</div>
              <div className="text-sm text-gray-600">Quizzes Completos</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{userStats.educationProgress}%</div>
              <div className="text-sm text-gray-600">Progresso Educação</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{userStats.gamesPlayed}</div>
              <div className="text-sm text-gray-600">Jogos Jogados</div>
            </div>
            
            <div className="text-center p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">{userStats.daysActive}</div>
              <div className="text-sm text-gray-600">Dias Ativo</div>
            </div>
          </div>
        </div>

        {/* Progresso de Prevenção */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Shield size={20} className="text-indigo-600" />
            Progresso de Prevenção
          </h2>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Conhecimento sobre Álcool</span>
                <span className="font-medium text-indigo-600">75%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full" style={{width: '75%'}}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Conhecimento sobre Drogas</span>
                <span className="font-medium text-indigo-600">60%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full" style={{width: '60%'}}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Estratégias de Prevenção</span>
                <span className="font-medium text-indigo-600">90%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full" style={{width: '90%'}}></div>
              </div>
            </div>
          </div>
        </div>

        {/* Botão de Logout */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-red-500 to-red-600 text-white py-4 rounded-xl font-semibold hover:from-red-600 hover:to-red-700 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <LogOut size={20} />
            Sair da Conta
          </button>
        </div>
      </div>
    </div>
  )
}

export default Account
