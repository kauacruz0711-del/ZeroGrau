
import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {BookOpen, Clock, User, TrendingUp, Award, CheckCircle, Star, Bookmark, Share2, Eye, FileText, Download, Search, Filter, BookmarkCheck} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import AchievementPopup from '../components/AchievementPopup'

interface ReadingContent {
  id: string
  title: string
  description: string
  category: 'alcohol' | 'drugs' | 'prevention' | 'health'
  type: 'article' | 'research' | 'guide' | 'story'
  readingTime: number // em minutos
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  thumbnail: string
  content: string
  completed: boolean
  rating: number
  author: string
  publishedAt: string
  tags: string[]
  wordCount: number
  readProgress: number
}

const Education = () => {
  const { userStats, updateStats, addExperience, unlockAchievement } = useAppStore()
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedContent, setSelectedContent] = useState<ReadingContent | null>(null)
  const [achievementToShow, setAchievementToShow] = useState<any>(null)
  const [bookmarkedItems, setBookmarkedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [readingProgress, setReadingProgress] = useState(0)
  const [currentReadingTime, setCurrentReadingTime] = useState(0)

  const categories = [
    { id: 'all', name: 'Todos', icon: '📚', color: 'bg-gray-500' },
    { id: 'alcohol', name: 'Álcool', icon: '🍺', color: 'bg-amber-500' },
    { id: 'drugs', name: 'Drogas', icon: '💊', color: 'bg-red-500' },
    { id: 'prevention', name: 'Prevenção', icon: '🛡️', color: 'bg-green-500' },
    { id: 'health', name: 'Saúde', icon: '❤️', color: 'bg-pink-500' }
  ]

  const readingContent: ReadingContent[] = [
    {
      id: '1',
      title: 'Os Efeitos do Álcool no Cérebro Adolescente',
      description: 'Compreenda como o álcool afeta especificamente o desenvolvimento cerebral dos jovens e suas consequências a longo prazo.',
      category: 'alcohol',
      type: 'article',
      readingTime: 8,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg',
      completed: false,
      rating: 4.8,
      author: 'Dr. Maria Silva',
      publishedAt: '2024-01-15',
      tags: ['neurociência', 'adolescência', 'desenvolvimento'],
      wordCount: 1200,
      readProgress: 0,
      content: `
        <h2>🧠 Introdução</h2>
        <p>O cérebro adolescente está em constante desenvolvimento até aproximadamente os 25 anos. Durante este período crítico, o consumo de álcool pode ter consequências duradouras e significativas para o futuro do jovem.</p>
        
        <h3>⚗️ Como o Álcool Afeta o Cérebro</h3>
        <p>O álcool é um depressor do sistema nervoso central que interfere na comunicação entre neurônios. No cérebro adolescente, isso pode:</p>
        <ul>
          <li><strong>Prejudicar o desenvolvimento do córtex pré-frontal</strong> - área responsável pela tomada de decisões</li>
          <li><strong>Afetar a formação de memórias</strong> - dificultando o aprendizado</li>
          <li><strong>Interferir na maturação neural</strong> - atrasando o desenvolvimento cognitivo</li>
          <li><strong>Reduzir a plasticidade cerebral</strong> - limitando a capacidade de adaptação</li>
        </ul>
        
        <h3>📊 Dados Científicos Alarmantes</h3>
        <p>Pesquisas recentes mostram que:</p>
        <ul>
          <li>Adolescentes que bebem regularmente têm <strong>10% menos volume de massa cinzenta</strong></li>
          <li>O risco de dependência aumenta em <strong>4x</strong> quando o consumo inicia antes dos 15 anos</li>
          <li>Problemas de memória podem persistir por <strong>até 2 anos</strong> após parar de beber</li>
        </ul>
        
        <h3>🔬 Consequências a Longo Prazo</h3>
        <p>Estudos longitudinais demonstram que adolescentes que consomem álcool regularmente podem apresentar:</p>
        <ul>
          <li><strong>Menor volume de massa cinzenta</strong> nas áreas frontais do cérebro</li>
          <li><strong>Problemas de memória persistentes</strong> que afetam o desempenho acadêmico</li>
          <li><strong>Dificuldades de concentração</strong> e atenção sustentada</li>
          <li><strong>Maior risco de dependência</strong> na vida adulta (até 5x maior)</li>
          <li><strong>Alterações no sistema de recompensa</strong> cerebral</li>
        </ul>
        
        <h3>💡 Prevenção e Conscientização</h3>
        <p>A educação é fundamental. Compreender esses riscos ajuda os jovens a tomar decisões mais informadas. Estratégias eficazes incluem:</p>
        <ul>
          <li>Diálogo aberto com pais e educadores</li>
          <li>Programas de prevenção baseados em evidências</li>
          <li>Desenvolvimento de habilidades de resistência à pressão social</li>
          <li>Promoção de atividades alternativas saudáveis</li>
        </ul>
        
        <h3>🎯 Conclusão</h3>
        <p>O cérebro adolescente é particularmente vulnerável aos efeitos do álcool. Investir em prevenção e educação é investir no futuro de toda uma geração.</p>
      `
    },
    {
      id: '2',
      title: 'Drogas Sintéticas: Uma Análise Científica',
      description: 'Estudo aprofundado sobre as drogas sintéticas mais comuns, seus mecanismos de ação e os riscos para a saúde.',
      category: 'drugs',
      type: 'research',
      readingTime: 15,
      difficulty: 'intermediate',
      thumbnail: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg',
      completed: false,
      rating: 4.9,
      author: 'Prof. João Santos',
      publishedAt: '2024-01-10',
      tags: ['drogas sintéticas', 'química', 'neurobiologia'],
      wordCount: 2100,
      readProgress: 0,
      content: `
        <h2>🧪 Introdução às Drogas Sintéticas</h2>
        <p>As drogas sintéticas representam uma das maiores ameaças à saúde pública contemporânea. Diferentemente das drogas naturais, estas são produzidas artificialmente em laboratórios clandestinos.</p>
        
        <h3>⚗️ Principais Categorias</h3>
        
        <h4>1. Estimulantes Sintéticos</h4>
        <ul>
          <li><strong>MDMA (Ecstasy)</strong> - Afeta serotonina, dopamina e noradrenalina</li>
          <li><strong>Anfetaminas</strong> - Estimulam o sistema nervoso central</li>
          <li><strong>Catinonas sintéticas</strong> - "Sais de banho" com efeitos imprevisíveis</li>
        </ul>
        
        <h4>2. Depressores Sintéticos</h4>
        <ul>
          <li><strong>GHB</strong> - "Droga do estupro", extremamente perigosa</li>
          <li><strong>Benzodiazepínicos</strong> - Altamente viciantes</li>
          <li><strong>Fentanil</strong> - 50x mais potente que a heroína</li>
        </ul>
        
        <h4>3. Alucinógenos Sintéticos</h4>
        <ul>
          <li><strong>LSD</strong> - Altera percepção e consciência</li>
          <li><strong>NBOMe</strong> - Extremamente tóxico em pequenas doses</li>
          <li><strong>2C-B</strong> - Combina efeitos estimulantes e alucinógenos</li>
        </ul>
        
        <h3>🧠 Mecanismos de Ação</h3>
        <p>As drogas sintéticas atuam interferindo nos neurotransmissores:</p>
        <ul>
          <li><strong>Dopamina</strong> - Sistema de recompensa e prazer</li>
          <li><strong>Serotonina</strong> - Humor, sono e apetite</li>
          <li><strong>GABA</strong> - Principal neurotransmissor inibitório</li>
          <li><strong>Glutamato</strong> - Principal neurotransmissor excitatório</li>
        </ul>
        
        <h3>⚠️ Riscos Específicos</h3>
        
        <h4>Riscos Imediatos</h4>
        <ul>
          <li>Overdose fatal (especialmente com fentanil)</li>
          <li>Hipertermia maligna</li>
          <li>Convulsões e parada cardíaca</li>
          <li>Psicose aguda</li>
        </ul>
        
        <h4>Riscos a Longo Prazo</h4>
        <ul>
          <li>Danos cerebrais irreversíveis</li>
          <li>Dependência física e psicológica</li>
          <li>Transtornos psiquiátricos persistentes</li>
          <li>Problemas cardiovasculares crônicos</li>
        </ul>
        
        <h3>📊 Estatísticas Alarmantes</h3>
        <ul>
          <li><strong>300%</strong> - Aumento de overdoses por fentanil nos últimos 5 anos</li>
          <li><strong>1 em 4</strong> - Jovens que experimentam drogas sintéticas desenvolvem dependência</li>
          <li><strong>85%</strong> - Das overdoses fatais envolvem drogas sintéticas</li>
        </ul>
        
        <h3>🛡️ Estratégias de Prevenção</h3>
        <ul>
          <li>Educação baseada em evidências científicas</li>
          <li>Programas de redução de danos</li>
          <li>Testes de pureza em festivais e eventos</li>
          <li>Tratamento especializado para dependência</li>
        </ul>
        
        <h3>🎯 Conclusão</h3>
        <p>As drogas sintéticas representam um desafio complexo que requer abordagem multidisciplinar, combinando prevenção, educação, tratamento e políticas públicas eficazes.</p>
      `
    },
    {
      id: '3',
      title: 'Manual de Estratégias de Prevenção',
      description: 'Guia prático com técnicas comprovadas para resistir à pressão social e tomar decisões saudáveis.',
      category: 'prevention',
      type: 'guide',
      readingTime: 12,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/3825463/pexels-photo-3825463.jpeg',
      completed: false,
      rating: 4.7,
      author: 'Equipe ZeroGrau',
      publishedAt: '2024-01-20',
      tags: ['prevenção', 'pressão social', 'habilidades'],
      wordCount: 1800,
      readProgress: 0,
      content: `
        <h2>🛡️ Estratégias Eficazes de Prevenção</h2>
        <p>A prevenção é a melhor ferramenta contra o uso de álcool e drogas. Este guia apresenta estratégias práticas e cientificamente comprovadas.</p>
        
        <h3>💪 Técnicas de Resistência à Pressão Social</h3>
        
        <h4>1. A Técnica do "NÃO" Assertivo</h4>
        <ul>
          <li><strong>Seja direto</strong>: "Não, obrigado. Não bebo."</li>
          <li><strong>Mantenha contato visual</strong> e postura firme</li>
          <li><strong>Não se justifique excessivamente</strong></li>
          <li><strong>Repita se necessário</strong> sem alterar o tom</li>
        </ul>
        
        <h4>2. Estratégia da Alternativa</h4>
        <ul>
          <li>"Prefiro um refrigerante, obrigado"</li>
          <li>"Vou dirigir hoje, então não posso"</li>
          <li>"Estou tomando medicação"</li>
          <li>"Tenho compromisso cedo amanhã"</li>
        </ul>
        
        <h4>3. Técnica do Desvio</h4>
        <ul>
          <li>Mude o assunto rapidamente</li>
          <li>Sugira uma atividade alternativa</li>
          <li>Faça uma pergunta sobre outro tópico</li>
          <li>Use humor apropriado para aliviar a tensão</li>
        </ul>
        
        <h3>🎯 Planejamento Estratégico</h3>
        
        <h4>Antes de Sair</h4>
        <ul>
          <li><strong>Defina seus limites</strong> e comprometa-se com eles</li>
          <li><strong>Tenha um plano de saída</strong> sempre pronto</li>
          <li><strong>Escolha amigos</strong> que respeitam suas decisões</li>
          <li><strong>Leve dinheiro</strong> para transporte alternativo</li>
        </ul>
        
        <h4>Durante Eventos Sociais</h4>
        <ul>
          <li>Mantenha-se hidratado com água</li>
          <li>Coma antes e durante o evento</li>
          <li>Fique próximo de amigos confiáveis</li>
          <li>Evite locais onde o uso é normalizado</li>
        </ul>
        
        <h3>🧠 Fortalecimento Mental</h3>
        
        <h4>Autoconhecimento</h4>
        <ul>
          <li><strong>Identifique seus gatilhos</strong> emocionais</li>
          <li><strong>Reconheça situações de risco</strong></li>
          <li><strong>Desenvolva autoestima</strong> independente de aprovação</li>
          <li><strong>Pratique mindfulness</strong> para clareza mental</li>
        </ul>
        
        <h4>Habilidades de Enfrentamento</h4>
        <ul>
          <li>Técnicas de respiração para ansiedade</li>
          <li>Exercícios físicos como válvula de escape</li>
          <li>Hobbies que proporcionem satisfação</li>
          <li>Rede de apoio emocional sólida</li>
        </ul>
        
        <h3>👥 Construindo Relacionamentos Saudáveis</h3>
        
        <h4>Características de Amigos Verdadeiros</h4>
        <ul>
          <li>Respeitam suas decisões sem pressionar</li>
          <li>Apoiam seus objetivos e valores</li>
          <li>Oferecem alternativas saudáveis de diversão</li>
          <li>Estão presentes nos momentos difíceis</li>
        </ul>
        
        <h4>Sinais de Relacionamentos Tóxicos</h4>
        <ul>
          <li>Pressão constante para usar substâncias</li>
          <li>Desrespeito aos seus limites</li>
          <li>Chantagem emocional ou social</li>
          <li>Isolamento de outros amigos/família</li>
        </ul>
        
        <h3>🎨 Atividades Alternativas</h3>
        
        <h4>Diversão Sem Substâncias</h4>
        <ul>
          <li><strong>Esportes</strong>: Futebol, basquete, natação, artes marciais</li>
          <li><strong>Arte</strong>: Música, pintura, teatro, dança</li>
          <li><strong>Tecnologia</strong>: Programação, design, jogos educativos</li>
          <li><strong>Voluntariado</strong>: Ajudar a comunidade, causas sociais</li>
        </ul>
        
        <h3>📱 Recursos de Apoio</h3>
        <ul>
          <li><strong>CVV</strong>: 188 (24h, gratuito)</li>
          <li><strong>CAPS</strong>: Centros de Atenção Psicossocial</li>
          <li><strong>Narcóticos Anônimos</strong>: Grupos de apoio</li>
          <li><strong>Apps de meditação</strong>: Calm, Headspace</li>
        </ul>
        
        <h3>🎯 Plano de Ação Pessoal</h3>
        <p>Crie seu próprio plano:</p>
        <ol>
          <li>Liste suas motivações para ficar livre de substâncias</li>
          <li>Identifique suas situações de risco</li>
          <li>Escolha 3 estratégias que mais fazem sentido para você</li>
          <li>Pratique essas estratégias em situações seguras</li>
          <li>Construa sua rede de apoio</li>
          <li>Revise e ajuste seu plano regularmente</li>
        </ol>
        
        <h3>💡 Lembre-se</h3>
        <p>A prevenção é um processo contínuo. Seja paciente consigo mesmo, celebre pequenas vitórias e não hesite em buscar ajuda quando necessário.</p>
      `
    },
    {
      id: '4',
      title: 'Sinais de Dependência: Guia de Identificação',
      description: 'Aprenda a reconhecer os primeiros sinais de dependência química em si mesmo ou em pessoas próximas.',
      category: 'health',
      type: 'guide',
      readingTime: 10,
      difficulty: 'intermediate',
      thumbnail: 'https://images.pexels.com/photos/3985163/pexels-photo-3985163.jpeg',
      completed: false,
      rating: 4.6,
      author: 'Dra. Ana Costa',
      publishedAt: '2024-01-08',
      tags: ['dependência', 'sinais', 'saúde mental'],
      wordCount: 1500,
      readProgress: 0,
      content: `
        <h2>🔍 Reconhecendo os Sinais de Dependência</h2>
        <p>A dependência química é uma doença progressiva que se desenvolve gradualmente. Reconhecer os sinais precoces é fundamental para buscar ajuda a tempo.</p>
        
        <h3>🚨 Sinais Físicos</h3>
        
        <h4>Mudanças na Aparência</h4>
        <ul>
          <li><strong>Perda ou ganho súbito de peso</strong></li>
          <li><strong>Olhos vermelhos</strong> ou pupilas dilatadas/contraídas</li>
          <li><strong>Negligência com higiene pessoal</strong></li>
          <li><strong>Tremores</strong> ou instabilidade motora</li>
          <li><strong>Marcas inexplicáveis</strong> no corpo</li>
        </ul>
        
        <h4>Sintomas Físicos</h4>
        <ul>
          <li>Fadiga extrema ou insônia</li>
          <li>Dores de cabeça frequentes</li>
          <li>Problemas digestivos</li>
          <li>Alterações no apetite</li>
          <li>Sintomas de abstinência</li>
        </ul>
        
        <h3>🧠 Sinais Comportamentais</h3>
        
        <h4>Mudanças no Comportamento</h4>
        <ul>
          <li><strong>Isolamento social</strong> progressivo</li>
          <li><strong>Mentiras frequentes</strong> sobre atividades</li>
          <li><strong>Mudanças drásticas de humor</strong></li>
          <li><strong>Agressividade</strong> ou irritabilidade</li>
          <li><strong>Perda de interesse</strong> em atividades prazerosas</li>
        </ul>
        
        <h4>Padrões de Uso</h4>
        <ul>
          <li>Uso em situações perigosas (dirigir, trabalhar)</li>
          <li>Incapacidade de controlar a quantidade</li>
          <li>Uso para lidar com emoções</li>
          <li>Tolerância aumentada (precisa de mais para o mesmo efeito)</li>
          <li>Sintomas de abstinência quando para</li>
        </ul>
        
        <h3>💭 Sinais Psicológicos</h3>
        
        <h4>Estado Mental</h4>
        <ul>
          <li><strong>Obsessão</strong> com a substância</li>
          <li><strong>Negação</strong> do problema</li>
          <li><strong>Ansiedade</strong> quando não pode usar</li>
          <li><strong>Depressão</strong> ou mudanças de humor</li>
          <li><strong>Paranoia</strong> ou pensamentos distorcidos</li>
        </ul>
        
        <h4>Funcionamento Cognitivo</h4>
        <ul>
          <li>Dificuldade de concentração</li>
          <li>Problemas de memória</li>
          <li>Tomada de decisões prejudicada</li>
          <li>Perda de julgamento crítico</li>
        </ul>
        
        <h3>🏠 Sinais Sociais e Familiares</h3>
        
        <h4>Relacionamentos</h4>
        <ul>
          <li><strong>Conflitos familiares</strong> aumentados</li>
          <li><strong>Perda de amigos</strong> antigos</li>
          <li><strong>Novos grupos sociais</strong> relacionados ao uso</li>
          <li><strong>Isolamento</strong> de pessoas próximas</li>
          <li><strong>Mentiras</strong> para familiares</li>
        </ul>
        
        <h4>Responsabilidades</h4>
        <ul>
          <li>Faltas no trabalho/escola</li>
          <li>Queda no desempenho</li>
          <li>Negligência com obrigações</li>
          <li>Problemas financeiros</li>
        </ul>
        
        <h3>📊 Escala de Gravidade</h3>
        
        <h4>🟢 Uso Experimental (Baixo Risco)</h4>
        <ul>
          <li>Uso ocasional em contextos sociais</li>
          <li>Mantém controle sobre quantidade</li>
          <li>Não interfere em responsabilidades</li>
          <li>Pode parar facilmente quando necessário</li>
        </ul>
        
        <h4>🟡 Uso Problemático (Risco Moderado)</h4>
        <ul>
          <li>Uso mais frequente</li>
          <li>Ocasionais problemas relacionados</li>
          <li>Dificuldade ocasional para controlar</li>
          <li>Alguns conflitos familiares/sociais</li>
        </ul>
        
        <h4>🔴 Dependência (Alto Risco)</h4>
        <ul>
          <li>Uso compulsivo e regular</li>
          <li>Perda significativa de controle</li>
          <li>Problemas graves em múltiplas áreas</li>
          <li>Sintomas de abstinência claros</li>
        </ul>
        
        <h3>🆘 Quando Buscar Ajuda</h3>
        
        <h4>Sinais de Alerta Imediato</h4>
        <ul>
          <li>Pensamentos suicidas</li>
          <li>Overdose ou intoxicação grave</li>
          <li>Comportamento violento</li>
          <li>Psicose ou delírios</li>
          <li>Sintomas de abstinência severos</li>
        </ul>
        
        <h4>Recursos Disponíveis</h4>
        <ul>
          <li><strong>CAPS-AD</strong>: Centros especializados em álcool e drogas</li>
          <li><strong>CVV 188</strong>: Apoio emocional 24h</li>
          <li><strong>Grupos de apoio</strong>: AA, NA, Al-Anon</li>
          <li><strong>Clínicas especializadas</strong>: Tratamento profissional</li>
          <li><strong>Psicólogos/Psiquiatras</strong>: Acompanhamento individual</li>
        </ul>
        
        <h3>💪 Como Abordar Alguém</h3>
        
        <h4>Estratégias Eficazes</h4>
        <ul>
          <li><strong>Escolha o momento certo</strong>: Quando a pessoa estiver sóbria</li>
          <li><strong>Use "eu" ao invés de "você"</strong>: "Eu me preocupo..." vs "Você é..."</li>
          <li><strong>Seja específico</strong>: Mencione comportamentos observados</li>
          <li><strong>Ofereça apoio</strong>: "Estou aqui para ajudar"</li>
          <li><strong>Evite julgamentos</strong>: Foque na preocupação, não na culpa</li>
        </ul>
        
        <h3>🎯 Lembre-se</h3>
        <ul>
          <li>A dependência é uma <strong>doença</strong>, não uma falha moral</li>
          <li>A <strong>negação</strong> é parte da doença</li>
          <li>O <strong>tratamento funciona</strong> quando há comprometimento</li>
          <li>A <strong>recaída não é fracasso</strong>, é parte do processo</li>
          <li>O <strong>apoio familiar</strong> é fundamental na recuperação</li>
        </ul>
      `
    },
    {
      id: '5',
      title: 'Histórias Reais de Superação',
      description: 'Relatos inspiradores de jovens que venceram a dependência e reconstruíram suas vidas.',
      category: 'prevention',
      type: 'story',
      readingTime: 6,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg',
      completed: false,
      rating: 4.5,
      author: 'Coletivo ZeroGrau',
      publishedAt: '2024-01-12',
      tags: ['superação', 'histórias reais', 'inspiração'],
      wordCount: 900,
      readProgress: 0,
      content: `
        <h2>💪 Histórias de Superação</h2>
        <p>Conheça relatos reais de jovens que enfrentaram a dependência e encontraram o caminho da recuperação. Suas histórias são prova de que a mudança é possível.</p>
        
        <h3>🌟 História 1: Lucas, 19 anos</h3>
        <blockquote>
          <p><em>"Comecei a beber aos 14 anos para me enturmar. O que era 'só nos finais de semana' virou todos os dias. Perdi amigos, reprovei na escola, e minha família não sabia mais o que fazer comigo."</em></p>
        </blockquote>
        
        <h4>O Ponto de Virada</h4>
        <p>Lucas conta que o momento decisivo foi quando acordou no hospital após uma intoxicação alcoólica grave. "Vi minha mãe chorando e percebi que não era só comigo que eu estava acabando."</p>
        
        <h4>O Processo de Recuperação</h4>
        <ul>
          <li><strong>Tratamento profissional</strong>: Internação em clínica especializada</li>
          <li><strong>Terapia individual</strong>: Sessões semanais com psicólogo</li>
          <li><strong>Grupos de apoio</strong>: Participação em AA jovens</li>
          <li><strong>Atividades saudáveis</strong>: Retomou o futebol e começou a tocar violão</li>
        </ul>
        
        <h4>Hoje</h4>
        <p>"Estou há 2 anos limpo. Voltei a estudar, tenho um emprego que gosto e relacionamentos saudáveis. A vida tem cor novamente."</p>
        
        <hr>
        
        <h3>🌸 História 2: Maria, 17 anos</h3>
        <blockquote>
          <p><em>"As drogas eram minha fuga da ansiedade e da depressão. Achava que me ajudavam, mas na verdade só pioravam tudo."</em></p>
        </blockquote>
        
        <h4>O Início</h4>
        <p>Maria começou usando maconha aos 15 anos para lidar com ataques de pânico. "Meus amigos diziam que era natural, que não fazia mal. Mas logo precisei de coisas mais fortes."</p>
        
        <h4>A Escalada</h4>
        <ul>
          <li>Passou para cocaína aos 16 anos</li>
          <li>Faltava constantemente à escola</li>
          <li>Roubava dinheiro de casa</li>
          <li>Teve overdose aos 17 anos</li>
        </ul>
        
        <h4>A Recuperação</h4>
        <p>"Minha família não desistiu de mim. Me internaram e, pela primeira vez, tive acesso a tratamento para ansiedade e depressão adequado."</p>
        
        <ul>
          <li><strong>Medicação apropriada</strong>: Para ansiedade e depressão</li>
          <li><strong>Terapia cognitivo-comportamental</strong>: Aprendeu técnicas de enfrentamento</li>
          <li><strong>Arte-terapia</strong>: Descobriu talento para pintura</li>
          <li><strong>Esporte</strong>: Começou a praticar yoga e corrida</li>
        </ul>
        
        <h4>Reflexão</h4>
        <p>"Descobri que as drogas não resolviam meus problemas, só os mascaravam. Hoje tenho ferramentas reais para lidar com a ansiedade."</p>
        
        <hr>
        
        <h3>🎯 História 3: Pedro, 20 anos</h3>
        <blockquote>
          <p><em>"Era o 'palhaço' da turma. Bebia para ser engraçado, para ser aceito. Não percebi quando virei o 'bêbado' da turma."</em></p>
        </blockquote>
        
        <h4>A Pressão Social</h4>
        <p>Pedro relata como a pressão para se encaixar o levou ao alcoolismo precoce. "Cada festa era uma competição para ver quem bebia mais. Eu sempre 'ganhava'."</p>
        
        <h4>As Consequências</h4>
        <ul>
          <li>Blackouts frequentes</li>
          <li>Comportamentos de risco</li>
          <li>Acidentes e brigas</li>
          <li>Perda de namorada e amigos próximos</li>
        </ul>
        
        <h4>O Despertar</h4>
        <p>"Acordei numa delegacia sem lembrar como tinha chegado lá. Tinha brigado com meu melhor amigo e o machucado. Foi quando percebi que tinha perdido o controle."</p>
        
        <h4>A Mudança</h4>
        <ul>
          <li><strong>Mudança de círculo social</strong>: Afastou-se de amigos que bebiam</li>
          <li><strong>Novos hobbies</strong>: Começou a praticar artes marciais</li>
          <li><strong>Voluntariado</strong>: Ajuda em projetos sociais</li>
          <li><strong>Estudos</strong>: Retomou faculdade de educação física</li>
        </ul>
        
        <h4>Mensagem</h4>
        <p>"Hoje sou engraçado por quem eu sou, não pelo que bebo. Meus amigos verdadeiros me respeitam pela minha personalidade, não pela minha capacidade de beber."</p>
        
        <hr>
        
        <h3>🔑 Lições Aprendidas</h3>
        
        <h4>Fatores Comuns de Sucesso</h4>
        <ul>
          <li><strong>Reconhecimento do problema</strong>: Admitir que precisava de ajuda</li>
          <li><strong>Apoio familiar</strong>: Família que não desistiu</li>
          <li><strong>Tratamento profissional</strong>: Ajuda especializada</li>
          <li><strong>Mudança de ambiente</strong>: Afastamento de gatilhos</li>
          <li><strong>Atividades substitutivas</strong>: Novos hobbies e interesses</li>
          <li><strong>Rede de apoio</strong>: Novos amigos e grupos de apoio</li>
        </ul>
        
        <h4>Desafios Enfrentados</h4>
        <ul>
          <li>Síndrome de abstinência</li>
          <li>Recaídas ocasionais</li>
          <li>Preconceito social</li>
          <li>Tentação em situações sociais</li>
          <li>Reconstrução de relacionamentos</li>
        </ul>
        
        <h3>💭 Mensagens de Esperança</h3>
        
        <blockquote>
          <p><strong>Lucas:</strong> <em>"Se eu consegui, qualquer um consegue. O primeiro passo é admitir que precisa de ajuda."</em></p>
        </blockquote>
        
        <blockquote>
          <p><strong>Maria:</strong> <em>"A recuperação não é linear, mas cada dia limpo é uma vitória. Celebre os pequenos progressos."</em></p>
        </blockquote>
        
        <blockquote>
          <p><strong>Pedro:</strong> <em>"Você não precisa tocar o fundo para pedir ajuda. Quanto mais cedo, melhor."</em></p>
        </blockquote>
        
        <h3>📞 Recursos de Ajuda</h3>
        <ul>
          <li><strong>CVV:</strong> 188 (24h, gratuito)</li>
          <li><strong>CAPS-AD:</strong> Centros de Atenção Psicossocial</li>
          <li><strong>AA/NA:</strong> Alcoólicos/Narcóticos Anônimos</li>
          <li><strong>Amor Exigente:</strong> Apoio às famílias</li>
        </ul>
        
        <h3>🎯 Lembre-se</h3>
        <p>Cada história de recuperação é única, mas todas têm algo em comum: <strong>a decisão de mudar</strong>. Se você ou alguém que conhece está passando por isso, saiba que a ajuda existe e a recuperação é possível.</p>
      `
    },
    {
      id: '6',
      title: 'Mitos e Verdades sobre Álcool e Drogas',
      description: 'Desmistificando conceitos errôneos e apresentando fatos científicos sobre substâncias psicoativas.',
      category: 'alcohol',
      type: 'article',
      readingTime: 9,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg',
      completed: false,
      rating: 4.4,
      author: 'Dr. Carlos Lima',
      publishedAt: '2024-01-12',
      tags: ['mitos', 'verdades', 'educação'],
      wordCount: 1300,
      readProgress: 0,
      content: `
        <h2>🔍 Separando Mitos de Verdades</h2>
        <p>Existem muitos conceitos errôneos sobre álcool e drogas circulando, especialmente entre jovens. Vamos esclarecer os principais mitos com base em evidências científicas.</p>
        
        <h3>🍺 Mitos sobre Álcool</h3>
        
        <h4>❌ MITO: "Cerveja não embriaga tanto quanto destilados"</h4>
        <p><strong>✅ VERDADE:</strong> O que importa é a quantidade de álcool consumida, não o tipo de bebida. Uma lata de cerveja (350ml, 5% álcool) tem praticamente a mesma quantidade de álcool que uma dose de cachaça (50ml, 40% álcool).</p>
        
        <h4>❌ MITO: "Café ou banho frio ajudam a ficar sóbrio"</h4>
        <p><strong>✅ VERDADE:</strong> Apenas o tempo elimina o álcool do organismo. O fígado processa aproximadamente uma dose por hora. Café pode deixar você mais alerta, mas não menos embriagado.</p>
        
        <h4>❌ MITO: "Beber com o estômago cheio evita embriaguez"</h4>
        <p><strong>✅ VERDADE:</strong> Comer antes de beber apenas retarda a absorção do álcool, mas não impede a embriaguez. O álcool ainda será absorvido completamente.</p>
        
        <h4>❌ MITO: "Álcool aquece o corpo"</h4>
        <p><strong>✅ VERDADE:</strong> O álcool dilata os vasos sanguíneos, criando sensação de calor, mas na verdade aumenta a perda de calor corporal, podendo causar hipotermia.</p>
        
        <h4>❌ MITO: "Vinho faz bem para o coração"</h4>
        <p><strong>✅ VERDADE:</strong> Estudos mostram que os benefícios vêm dos antioxidantes da uva, não do álcool. Suco de uva integral tem os mesmos benefícios sem os riscos.</p>
        
        <h3>💊 Mitos sobre Drogas</h3>
        
        <h4>❌ MITO: "Maconha não vicia"</h4>
        <p><strong>✅ VERDADE:</strong> Cerca de 9% dos usuários desenvolvem dependência, subindo para 17% entre adolescentes. O risco é real, especialmente com uso regular.</p>
        
        <h4>❌ MITO: "Drogas naturais são seguras"</h4>
        <p><strong>✅ VERDADE:</strong> "Natural" não significa seguro. Cogumelos alucinógenos, ayahuasca e outras substâncias naturais podem ser extremamente perigosas.</p>
        
        <h4>❌ MITO: "Ecstasy é seguro se for puro"</h4>
        <p><strong>✅ VERDADE:</strong> Mesmo o MDMA "puro" pode causar hipertermia fatal, problemas cardíacos e danos cerebrais permanentes.</p>
        
        <h4>❌ MITO: "LSD fica no organismo para sempre"</h4>
        <p><strong>✅ VERDADE:</strong> O LSD é eliminado rapidamente do corpo. Os "flashbacks" são raros e têm outras explicações neurológicas.</p>
        
        <h4>❌ MITO: "Crack vicia na primeira vez"</h4>
        <p><strong>✅ VERDADE:</strong> Embora o crack seja extremamente viciante, a dependência se desenvolve rapidamente, mas não necessariamente na primeira experiência.</p>
        
        <h3>🧠 Mitos sobre Dependência</h3>
        
        <h4>❌ MITO: "Dependência é falta de força de vontade"</h4>
        <p><strong>✅ VERDADE:</strong> Dependência é uma doença cerebral crônica que altera circuitos neurais relacionados a recompensa, motivação e memória.</p>
        
        <h4>❌ MITO: "Só pessoas fracas se tornam dependentes"</h4>
        <p><strong>✅ VERDADE:</strong> A dependência afeta pessoas de todas as classes sociais, níveis de educação e personalidades. Fatores genéticos representam 40-60% do risco.</p>
        
        <h4>❌ MITO: "Quem quer parar, para"</h4>
        <p><strong>✅ VERDADE:</strong> A dependência altera o cérebro de forma que torna extremamente difícil parar sem ajuda profissional. Tratamento é necessário.</p>
        
        <h4>❌ MITO: "Recaída significa fracasso do tratamento"</h4>
        <p><strong>✅ VERDADE:</strong> Recaídas são comuns e fazem parte do processo de recuperação. Não significam que o tratamento falhou.</p>
        
        <h3>👥 Mitos sobre Prevenção</h3>
        
        <h4>❌ MITO: "Falar sobre drogas incentiva o uso"</h4>
        <p><strong>✅ VERDADE:</strong> Educação baseada em evidências reduz o uso. Informação precisa ajuda jovens a tomar decisões mais seguras.</p>
        
        <h4>❌ MITO: "Estratégias de 'tolerância zero' são mais eficazes"</h4>
        <p><strong>✅ VERDADE:</strong> Abordagens punitivas são menos eficazes que programas de prevenção e tratamento baseados em evidências.</p>
        
        <h4>❌ MITO: "Programas de redução de danos incentivam o uso"</h4>
        <p><strong>✅ VERDADE:</strong> Redução de danos salva vidas e não aumenta o consumo. Foco na segurança, não na abstinência absoluta.</p>
        
        <h3>📊 Dados Científicos Importantes</h3>
        
        <h4>Álcool</h4>
        <ul>
          <li><strong>3ª causa</strong> de morte evitável no mundo</li>
          <li><strong>200+</strong> doenças relacionadas ao consumo</li>
          <li><strong>40%</strong> dos acidentes de trânsito envolvem álcool</li>
          <li><strong>25 anos</strong> - idade quando o cérebro termina de se desenvolver</li>
        </ul>
        
        <h4>Drogas Ilícitas</h4>
        <ul>
          <li><strong>271 milhões</strong> de pessoas usaram drogas em 2019</li>
          <li><strong>35 milhões</strong> sofrem de transtornos por uso de drogas</li>
          <li><strong>500.000</strong> mortes anuais relacionadas a drogas</li>
          <li><strong>1 em 8</strong> pessoas que experimentam desenvolvem dependência</li>
        </ul>
        
        <h3>🎯 Fatores de Risco Reais</h3>
        
        <h4>Biológicos</h4>
        <ul>
          <li>Genética (40-60% do risco)</li>
          <li>Transtornos mentais</li>
          <li>Início precoce do uso</li>
          <li>Sexo masculino (maior risco)</li>
        </ul>
        
        <h4>Psicológicos</h4>
        <ul>
          <li>Trauma na infância</li>
          <li>Baixa autoestima</li>
          <li>Impulsividade</li>
          <li>Busca por sensações</li>
        </ul>
        
        <h4>Sociais</h4>
        <ul>
          <li>Pressão dos pares</li>
          <li>Disponibilidade da substância</li>
          <li>Normas sociais permissivas</li>
          <li>Estresse familiar</li>
        </ul>
        
        <h3>🛡️ Fatores de Proteção</h3>
        
        <h4>Individuais</h4>
        <ul>
          <li>Habilidades de enfrentamento</li>
          <li>Autoeficácia</li>
          <li>Religiosidade/espiritualidade</li>
          <li>Orientação para o futuro</li>
        </ul>
        
        <h4>Familiares</h4>
        <ul>
          <li>Vínculos familiares fortes</li>
          <li>Supervisão adequada</li>
          <li>Comunicação aberta</li>
          <li>Limites claros</li>
        </ul>
        
        <h4>Comunitários</h4>
        <ul>
          <li>Conexão escolar</li>
          <li>Atividades extracurriculares</li>
          <li>Mentores positivos</li>
          <li>Oportunidades de envolvimento</li>
        </ul>
        
        <h3>💡 Conclusão</h3>
        <p>Conhecimento baseado em evidências é nossa melhor ferramenta contra o uso problemático de substâncias. Questione sempre informações duvidosas e busque fontes confiáveis.</p>
        
        <h4>Fontes Confiáveis</h4>
        <ul>
          <li>Organização Mundial da Saúde (OMS)</li>
          <li>SENAD - Secretaria Nacional de Políticas sobre Drogas</li>
          <li>UNIFESP - Universidade Federal de São Paulo</li>
          <li>Instituto Nacional sobre Abuso de Drogas (NIDA)</li>
        </ul>
      `
    }
  ]

  const filteredContent = selectedCategory === 'all' 
    ? readingContent 
    : readingContent.filter(content => content.category === selectedCategory)

  const searchFilteredContent = searchQuery 
    ? filteredContent.filter(content => 
        content.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        content.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        content.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : filteredContent

  const handleContentClick = (content: ReadingContent) => {
    setSelectedContent(content)
    setReadingProgress(0)
    setCurrentReadingTime(0)
    
    // Simular progresso de leitura
    const timer = setInterval(() => {
      setCurrentReadingTime(prev => {
        const newTime = prev + 1
        const progress = Math.min((newTime / (content.readingTime * 60)) * 100, 100)
        setReadingProgress(progress)
        
        if (progress >= 100) {
          clearInterval(timer)
          
          if (!content.completed) {
            // Adicionar experiência baseada no tipo de conteúdo
            const experienceGain = content.type === 'research' ? 75 : 
                                 content.type === 'guide' ? 60 : 50
            addExperience(experienceGain)
            
            // Atualizar estatísticas
            const newStats = {
              articlesRead: userStats.articlesRead + 1,
              educationProgress: Math.min(userStats.educationProgress + 15, 100),
              totalTimeSpent: userStats.totalTimeSpent + content.readingTime
            }
            updateStats(newStats)
            
            // Verificar conquistas
            if (userStats.articlesRead === 0) {
              unlockAchievement('first_article')
              const achievement = userStats.achievements.find(a => a.id === 'first_article')
              if (achievement) setAchievementToShow(achievement)
            }
            
            if (newStats.articlesRead >= 10) {
              unlockAchievement('video_watcher') // Reutilizando para leitura
            }
            
            if (newStats.educationProgress >= 100) {
              unlockAchievement('education_master')
            }
            
            // Marcar como concluído
            content.completed = true
          }
        }
        
        return newTime
      })
    }, 1000)
    
    return () => clearInterval(timer)
  }

  const toggleBookmark = (contentId: string) => {
    setBookmarkedItems(prev => 
      prev.includes(contentId) 
        ? prev.filter(id => id !== contentId)
        : [...prev, contentId]
    )
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800'
      case 'advanced': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'article': return <BookOpen size={16} />
      case 'research': return <FileText size={16} />
      case 'guide': return <TrendingUp size={16} />
      case 'story': return <User size={16} />
      default: return <BookOpen size={16} />
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'article': return 'Artigo'
      case 'research': return 'Pesquisa'
      case 'guide': return 'Guia'
      case 'story': return 'História'
      default: return 'Conteúdo'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pb-24 pt-4">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-6 py-6"
      >
        <div className="text-center">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg"
          >
            <BookOpen size={32} className="text-white" />
          </motion.div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Biblioteca Digital</h1>
          <p className="text-gray-600">Conteúdo científico e educativo sobre prevenção</p>
        </div>

        {/* Progress Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 bg-white rounded-2xl shadow-lg p-4"
        >
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">Progresso de Leitura</h3>
            <span className="text-2xl">📖</span>
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-blue-600">{userStats.articlesRead}</div>
              <div className="text-xs text-gray-600">Artigos Lidos</div>
            </div>
            <div>
              <div className="text-xl font-bold text-purple-600">{Math.floor(userStats.totalTimeSpent)}min</div>
              <div className="text-xs text-gray-600">Tempo de Leitura</div>
            </div>
            <div>
              <div className="text-xl font-bold text-green-600">{userStats.educationProgress}%</div>
              <div className="text-xs text-gray-600">Progresso Total</div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Search Bar */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
        className="px-6 mb-4"
      >
        <div className="relative">
          <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar artigos, guias ou pesquisas..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
          />
        </div>
      </motion.div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.4 }}
        className="px-6 mb-6"
      >
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === category.id
                  ? `${category.color} text-white shadow-lg`
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
              }`}
            >
              <span>{category.icon}</span>
              <span className="text-sm font-medium">{category.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Content Grid */}
      <div className="px-6">
        <div className="grid gap-4">
          {searchFilteredContent.map((content, index) => (
            <motion.div
              key={content.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100"
            >
              <div className="relative">
                <img
                  src={content.thumbnail}
                  alt={content.title}
                  className="w-full h-48 object-cover"
                />
                
                {/* Overlay com informações */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                
                {/* Status badges */}
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(content.difficulty)}`}>
                    {content.difficulty}
                  </span>
                  <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-500 text-white flex items-center gap-1">
                    {getTypeIcon(content.type)}
                    {getTypeLabel(content.type)}
                  </span>
                  {content.completed && (
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-500 text-white flex items-center gap-1">
                      <CheckCircle size={12} />
                      Lido
                    </span>
                  )}
                </div>

                {/* Action buttons */}
                <div className="absolute top-3 right-3 flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleBookmark(content.id)
                    }}
                    className={`p-2 rounded-full ${
                      bookmarkedItems.includes(content.id)
                        ? 'bg-yellow-500 text-white'
                        : 'bg-white/80 text-gray-600'
                    }`}
                  >
                    <Bookmark size={16} />
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-full bg-white/80 text-gray-600"
                  >
                    <Share2 size={16} />
                  </motion.button>
                </div>

                {/* Reading time and word count */}
                <div className="absolute bottom-3 left-3 flex items-center gap-3 text-white">
                  <span className="text-sm font-medium flex items-center gap-1">
                    <Clock size={12} />
                    {content.readingTime} min
                  </span>
                  <span className="text-sm font-medium flex items-center gap-1">
                    <Eye size={12} />
                    {content.wordCount} palavras
                  </span>
                </div>

                {/* Rating */}
                <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white">
                  <Star size={12} className="fill-current" />
                  <span className="text-sm font-medium">{content.rating}</span>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <User size={14} className="text-gray-500" />
                  <span className="text-sm text-gray-600">{content.author}</span>
                  <span className="text-sm text-gray-400">•</span>
                  <span className="text-sm text-gray-600">{content.publishedAt}</span>
                </div>

                <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2">
                  {content.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {content.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {content.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Progress bar for read content */}
                {content.readProgress > 0 && (
                  <div className="mb-3">
                    <div className="flex justify-between text-xs text-gray-600 mb-1">
                      <span>Progresso de Leitura</span>
                      <span>{Math.round(content.readProgress)}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all"
                        style={{ width: `${content.readProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleContentClick(content)}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all"
                >
                  {content.completed ? (
                    <>
                      <BookmarkCheck size={20} />
                      Reler Conteúdo
                    </>
                  ) : (
                    <>
                      {getTypeIcon(content.type)}
                      Ler Agora
                    </>
                  )}
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Reading Modal */}
      {selectedContent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedContent(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 border-b border-gray-200 sticky top-0 bg-white z-10">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {getTypeIcon(selectedContent.type)}
                  <span className="text-sm font-medium text-gray-600">
                    {getTypeLabel(selectedContent.type)}
                  </span>
                </div>
                <button
                  onClick={() => setSelectedContent(null)}
                  className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  ✕
                </button>
              </div>
              
              <h2 className="text-xl font-bold text-gray-800 mb-2">{selectedContent.title}</h2>
              
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span className="flex items-center gap-1">
                  <User size={14} />
                  {selectedContent.author}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={14} />
                  {selectedContent.readingTime} min
                </span>
                <span className="flex items-center gap-1">
                  <Eye size={14} />
                  {selectedContent.wordCount} palavras
                </span>
              </div>
              
              {/* Progress Bar */}
              <div className="mt-3">
                <div className="flex justify-between text-xs text-gray-600 mb-1">
                  <span>Progresso de Leitura</span>
                  <span>{Math.round(readingProgress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all"
                    style={{ width: `${readingProgress}%` }}
                  />
                </div>
              </div>
            </div>
            
            {/* Content */}
            <div className="max-h-[70vh] overflow-y-auto p-6">
              <div
                className="prose prose-sm max-w-none text-gray-700 leading-relaxed"
                dangerouslySetInnerHTML={{ __html: selectedContent.content }}
              />
            </div>
            
            {/* Footer */}
            <div className="p-4 border-t border-gray-200 bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => toggleBookmark(selectedContent.id)}
                    className={`p-2 rounded-full ${
                      bookmarkedItems.includes(selectedContent.id)
                        ? 'bg-yellow-500 text-white'
                        : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                    }`}
                  >
                    <Bookmark size={16} />
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-full bg-gray-200 text-gray-600 hover:bg-gray-300"
                  >
                    <Share2 size={16} />
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-full bg-gray-200 text-gray-600 hover:bg-gray-300"
                  >
                    <Download size={16} />
                  </motion.button>
                </div>
                
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star size={16} className="fill-current" />
                  <span className="text-sm font-medium text-gray-700">{selectedContent.rating}</span>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}

      <AchievementPopup
        achievement={achievementToShow}
        onClose={() => setAchievementToShow(null)}
      />
    </div>
  )
}

export default Education
