
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  unlocked: boolean
  unlockedAt?: string
  category: 'education' | 'quiz' | 'games' | 'prevention' | 'social'
  rarity: 'common' | 'rare' | 'epic' | 'legendary'
}

interface UserStats {
  totalPoints: number
  level: number
  experiencePoints: number
  experienceToNextLevel: number
  streak: number
  longestStreak: number
  lastActiveDate: string
  
  // Estatísticas por categoria
  educationProgress: number
  quizzesCompleted: number
  quizAccuracy: number
  gamesPlayed: number
  preventionTipsRead: number
  
  // Estatísticas detalhadas
  totalTimeSpent: number // em minutos
  articlesRead: number
  videosWatched: number
  interactionsCount: number
  
  // Conquistas
  achievements: Achievement[]
  unlockedAchievements: number
}

interface AppState {
  userStats: UserStats
  currentTheme: 'light' | 'dark'
  notificationsEnabled: boolean
  soundEnabled: boolean
  
  // Actions
  updateStats: (stats: Partial<UserStats>) => void
  addExperience: (points: number) => void
  unlockAchievement: (achievementId: string) => void
  updateStreak: () => void
  setTheme: (theme: 'light' | 'dark') => void
  toggleNotifications: () => void
  toggleSound: () => void
}

const initialAchievements: Achievement[] = [
  // Educação
  { id: 'first_article', title: 'Primeiro Passo', description: 'Leu seu primeiro artigo educativo', icon: '📚', unlocked: false, category: 'education', rarity: 'common' },
  { id: 'education_master', title: 'Mestre da Educação', description: 'Completou 100% do conteúdo educativo', icon: '🎓', unlocked: false, category: 'education', rarity: 'legendary' },
  { id: 'video_watcher', title: 'Observador', description: 'Assistiu 10 vídeos educativos', icon: '🎥', unlocked: false, category: 'education', rarity: 'rare' },
  
  // Quiz
  { id: 'first_quiz', title: 'Primeira Tentativa', description: 'Completou seu primeiro quiz', icon: '🧠', unlocked: false, category: 'quiz', rarity: 'common' },
  { id: 'quiz_perfectionist', title: 'Perfeccionista', description: 'Acertou 100% em um quiz', icon: '⭐', unlocked: false, category: 'quiz', rarity: 'epic' },
  { id: 'quiz_marathon', title: 'Maratonista', description: 'Completou 50 quizzes', icon: '🏃‍♂️', unlocked: false, category: 'quiz', rarity: 'rare' },
  
  // Jogos
  { id: 'first_game', title: 'Jogador Iniciante', description: 'Jogou seu primeiro jogo', icon: '🎮', unlocked: false, category: 'games', rarity: 'common' },
  { id: 'game_champion', title: 'Campeão dos Jogos', description: 'Venceu 25 jogos', icon: '🏆', unlocked: false, category: 'games', rarity: 'epic' },
  
  // Prevenção
  { id: 'prevention_aware', title: 'Consciente', description: 'Leu 20 dicas de prevenção', icon: '🛡️', unlocked: false, category: 'prevention', rarity: 'rare' },
  { id: 'help_seeker', title: 'Buscador de Ajuda', description: 'Acessou recursos de ajuda', icon: '🤝', unlocked: false, category: 'prevention', rarity: 'common' },
  
  // Sociais
  { id: 'week_streak', title: 'Semana Dedicada', description: 'Manteve streak de 7 dias', icon: '🔥', unlocked: false, category: 'social', rarity: 'rare' },
  { id: 'month_streak', title: 'Mês Consistente', description: 'Manteve streak de 30 dias', icon: '💎', unlocked: false, category: 'social', rarity: 'legendary' },
  { id: 'early_bird', title: 'Madrugador', description: 'Usou o app antes das 8h', icon: '🌅', unlocked: false, category: 'social', rarity: 'common' },
  { id: 'night_owl', title: 'Coruja Noturna', description: 'Usou o app depois das 22h', icon: '🦉', unlocked: false, category: 'social', rarity: 'common' }
]

const calculateLevel = (experience: number): { level: number; experienceToNext: number } => {
  const level = Math.floor(experience / 1000) + 1
  const experienceToNext = 1000 - (experience % 1000)
  return { level, experienceToNext }
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      userStats: {
        totalPoints: 0,
        level: 1,
        experiencePoints: 0,
        experienceToNextLevel: 1000,
        streak: 0,
        longestStreak: 0,
        lastActiveDate: new Date().toISOString().split('T')[0],
        
        educationProgress: 0,
        quizzesCompleted: 0,
        quizAccuracy: 0,
        gamesPlayed: 0,
        preventionTipsRead: 0,
        
        totalTimeSpent: 0,
        articlesRead: 0,
        videosWatched: 0,
        interactionsCount: 0,
        
        achievements: initialAchievements,
        unlockedAchievements: 0
      },
      currentTheme: 'light',
      notificationsEnabled: true,
      soundEnabled: true,
      
      updateStats: (newStats) => set((state) => ({
        userStats: { ...state.userStats, ...newStats }
      })),
      
      addExperience: (points) => set((state) => {
        const newExperience = state.userStats.experiencePoints + points
        const { level, experienceToNext } = calculateLevel(newExperience)
        
        return {
          userStats: {
            ...state.userStats,
            experiencePoints: newExperience,
            level,
            experienceToNextLevel: experienceToNext,
            totalPoints: state.userStats.totalPoints + points
          }
        }
      }),
      
      unlockAchievement: (achievementId) => set((state) => {
        const achievements = state.userStats.achievements.map(achievement =>
          achievement.id === achievementId
            ? { ...achievement, unlocked: true, unlockedAt: new Date().toISOString() }
            : achievement
        )
        
        const unlockedCount = achievements.filter(a => a.unlocked).length
        
        return {
          userStats: {
            ...state.userStats,
            achievements,
            unlockedAchievements: unlockedCount
          }
        }
      }),
      
      updateStreak: () => set((state) => {
        const today = new Date().toISOString().split('T')[0]
        const lastActive = state.userStats.lastActiveDate
        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)
        const yesterdayStr = yesterday.toISOString().split('T')[0]
        
        let newStreak = state.userStats.streak
        
        if (lastActive === yesterdayStr) {
          // Continuou o streak
          newStreak += 1
        } else if (lastActive !== today) {
          // Quebrou o streak
          newStreak = 1
        }
        
        return {
          userStats: {
            ...state.userStats,
            streak: newStreak,
            longestStreak: Math.max(state.userStats.longestStreak, newStreak),
            lastActiveDate: today
          }
        }
      }),
      
      setTheme: (theme) => set({ currentTheme: theme }),
      toggleNotifications: () => set((state) => ({ notificationsEnabled: !state.notificationsEnabled })),
      toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled }))
    }),
    {
      name: 'zerograu-app-storage'
    }
  )
)
