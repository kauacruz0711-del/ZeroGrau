
import React, { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAuthStore } from './store/authStore'
import LoginScreen from './components/LoginScreen'
import Home from './pages/Home'
import Education from './pages/Education'
import Quiz from './pages/Quiz'
import Games from './pages/Games'
import Prevention from './pages/Prevention'
import Account from './pages/Account'
import Navigation from './components/Navigation'

function App() {
  const { isAuthenticated, loading, user, initialize } = useAuthStore()

  useEffect(() => {
    console.log('🚀 App montado - inicializando...')
    initialize()
  }, [initialize])

  // Debug detalhado
  useEffect(() => {
    console.log('🔍 Estado atual:', { 
      isAuthenticated, 
      loading, 
      userEmail: user?.email,
      timestamp: new Date().toISOString()
    })
  }, [isAuthenticated, loading, user])

  // Loading state
  if (loading) {
    console.log('⏳ Mostrando loading...')
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-3"></div>
          <p className="text-white text-base font-medium">Iniciando ZeroGrau...</p>
        </div>
      </div>
    )
  }

  // Login screen
  if (!isAuthenticated) {
    console.log('🔑 Mostrando tela de login')
    return (
      <>
        <LoginScreen />
        <Toaster 
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              fontWeight: 'bold',
              borderRadius: '12px'
            }
          }}
        />
      </>
    )
  }

  // Main app
  console.log('🏠 Mostrando app principal para:', user?.email)
  return (
    <>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <div className="max-w-md mx-auto bg-white shadow-lg min-h-screen">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/education" element={<Education />} />
              <Route path="/quiz" element={<Quiz />} />
              <Route path="/games" element={<Games />} />
              <Route path="/prevention" element={<Prevention />} />
              <Route path="/account" element={<Account />} />
            </Routes>
            <Navigation />
          </div>
        </div>
      </Router>
      <Toaster 
        position="top-center"
        toastOptions={{
          duration: 3000,
          style: {
            fontWeight: 'bold',
            borderRadius: '12px'
          }
        }}
      />
    </>
  )
}

export default App
