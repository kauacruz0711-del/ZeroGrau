
import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {ArrowLeft, Shield, Phone, Heart, Users, AlertTriangle, CheckCircle, ExternalLink} from 'lucide-react'
import { Link } from 'react-router-dom'

const Prevention = () => {
  const [selectedTab, setSelectedTab] = useState('tips')

  const preventionTips = [
    {
      icon: <Users className="w-6 h-6" />,
      title: "Escolha bem suas companhias",
      description: "Cerque-se de amigos que respeitam suas escolhas e não pressionam você a usar drogas.",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Cuide da sua autoestima",
      description: "Pratique atividades que você gosta e desenvolva hobbies saudáveis.",
      color: "from-green-500 to-green-600"
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Aprenda a dizer NÃO",
      description: "É seu direito recusar ofertas de drogas. Seja firme e não se justifique.",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: <CheckCircle className="w-6 h-6" />,
      title: "Busque atividades saudáveis",
      description: "Esporte, música, arte, voluntariado - encontre o que te faz feliz sem drogas.",
      color: "from-orange-500 to-orange-600"
    }
  ]

  const warningSignals = [
    "Mudanças bruscas de comportamento",
    "Isolamento social e familiar",
    "Queda no rendimento escolar",
    "Mudança no grupo de amigos",
    "Mentiras frequentes",
    "Problemas financeiros inexplicáveis",
    "Alterações no sono e apetite",
    "Agressividade ou irritabilidade"
  ]

  const emergencyContacts = [
    {
      name: "CVV - Centro de Valorização da Vida",
      number: "188",
      description: "Apoio emocional e prevenção do suicídio",
      available: "24h"
    },
    {
      name: "Disque Saúde",
      number: "136",
      description: "Informações sobre saúde e drogas",
      available: "24h"
    },
    {
      name: "SAMU",
      number: "192",
      description: "Emergências médicas",
      available: "24h"
    },
    {
      name: "Polícia Militar",
      number: "190",
      description: "Emergências e segurança",
      available: "24h"
    }
  ]

  const tabs = [
    { id: 'tips', label: 'Dicas', icon: <Shield className="w-5 h-5" /> },
    { id: 'signals', label: 'Sinais', icon: <AlertTriangle className="w-5 h-5" /> },
    { id: 'help', label: 'Ajuda', icon: <Phone className="w-5 h-5" /> }
  ]

  return (
    <div className="p-6 pb-24">
      {/* Header */}
      <div className="flex items-center mb-6">
        <Link to="/">
          <ArrowLeft className="w-6 h-6 text-gray-600 mr-4" />
        </Link>
        <h1 className="text-xl font-bold text-gray-800">Prevenção</h1>
      </div>

      {/* Tabs */}
      <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
        {tabs.map((tab) => (
          <motion.button
            key={tab.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelectedTab(tab.id)}
            className={`flex-1 flex items-center justify-center py-2 px-3 rounded-lg transition-all ${
              selectedTab === tab.id
                ? 'bg-white shadow-md text-blue-600'
                : 'text-gray-600'
            }`}
          >
            {tab.icon}
            <span className="ml-2 text-sm font-medium">{tab.label}</span>
          </motion.button>
        ))}
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {selectedTab === 'tips' && (
          <motion.div
            key="tips"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 rounded-2xl text-white mb-6">
              <h2 className="font-bold text-lg mb-2">💚 Dicas de Prevenção</h2>
              <p className="text-sm opacity-90">
                Pequenas atitudes podem fazer uma grande diferença na sua vida!
              </p>
            </div>

            {preventionTips.map((tip, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-4 shadow-lg border border-gray-100"
              >
                <div className="flex items-start">
                  <div className={`bg-gradient-to-r ${tip.color} p-2 rounded-xl text-white mr-4 flex-shrink-0`}>
                    {tip.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800 mb-2">{tip.title}</h3>
                    <p className="text-sm text-gray-600">{tip.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mt-6"
            >
              <h3 className="font-bold text-blue-800 mb-2">💡 Lembre-se</h3>
              <p className="text-sm text-blue-700">
                Não existe "experimentar só uma vez". Toda dependência começou com a primeira vez. Sua vida vale mais que qualquer curiosidade!
              </p>
            </motion.div>
          </motion.div>
        )}

        {selectedTab === 'signals' && (
          <motion.div
            key="signals"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4 rounded-2xl text-white mb-6">
              <h2 className="font-bold text-lg mb-2">⚠️ Sinais de Alerta</h2>
              <p className="text-sm opacity-90">
                Fique atento a estes sinais em você ou em pessoas próximas
              </p>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-lg">
              <h3 className="font-bold text-gray-800 mb-4">Possíveis sinais de uso de drogas:</h3>
              <div className="space-y-3">
                {warningSignals.map((signal, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center"
                  >
                    <div className="w-2 h-2 bg-red-400 rounded-full mr-3 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{signal}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mt-6"
            >
              <h3 className="font-bold text-yellow-800 mb-2">⚡ O que fazer?</h3>
              <div className="text-sm text-yellow-700 space-y-2">
                <p>• Converse com a pessoa sem julgamentos</p>
                <p>• Busque ajuda de profissionais especializados</p>
                <p>• Ofereça apoio e compreensão</p>
                <p>• Não ignore os sinais - aja com amor</p>
              </div>
            </motion.div>
          </motion.div>
        )}

        {selectedTab === 'help' && (
          <motion.div
            key="help"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-4 rounded-2xl text-white mb-6">
              <h2 className="font-bold text-lg mb-2">📞 Busque Ajuda</h2>
              <p className="text-sm opacity-90">
                Você não está sozinho. Existem pessoas prontas para ajudar!
              </p>
            </div>

            <div className="space-y-4">
              {emergencyContacts.map((contact, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl p-4 shadow-lg border border-gray-100"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-800 mb-1">{contact.name}</h3>
                      <p className="text-sm text-gray-600 mb-2">{contact.description}</p>
                      <span className="text-xs bg-green-100 text-green-600 px-2 py-1 rounded-full">
                        {contact.available}
                      </span>
                    </div>
                    <div className="text-right ml-4">
                      <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 rounded-xl font-bold text-lg">
                        {contact.number}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-green-50 border border-green-200 rounded-2xl p-4 mt-6"
            >
              <h3 className="font-bold text-green-800 mb-2 flex items-center">
                <Heart className="w-5 h-5 mr-2" />
                Lembre-se
              </h3>
              <p className="text-sm text-green-700">
                Pedir ajuda é um sinal de coragem, não de fraqueza. Quanto mais cedo buscar apoio, melhores são as chances de recuperação e prevenção.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mt-4"
            >
              <h3 className="font-bold text-blue-800 mb-2">🌐 Recursos Online</h3>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-blue-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  <span>CAPS - Centros de Atenção Psicossocial</span>
                </div>
                <div className="flex items-center text-sm text-blue-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  <span>UBS - Unidades Básicas de Saúde</span>
                </div>
                <div className="flex items-center text-sm text-blue-700">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  <span>Narcóticos Anônimos (NA)</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default Prevention
