
import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {BookOpen, Play, Clock, User, TrendingUp, Award, CheckCircle, Lock, Star, Download, Share2, Bookmark} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import AchievementPopup from '../components/AchievementPopup'

interface EducationalContent {
  id: string
  title: string
  description: string
  category: 'alcohol' | 'drugs' | 'prevention' | 'health'
  type: 'article' | 'video' | 'infographic'
  duration: number // em minutos
  difficulty: 'beginner' | 'intermediate' | 'advanced'
  thumbnail: string
  content?: string
  videoUrl?: string
  completed: boolean
  rating: number
  author: string
  publishedAt: string
  tags: string[]
}

const Education = () => {
  const { userStats, updateStats, addExperience, unlockAchievement } = useAppStore()
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedContent, setSelectedContent] = useState<EducationalContent | null>(null)
  const [achievementToShow, setAchievementToShow] = useState<any>(null)
  const [bookmarkedItems, setBookmarkedItems] = useState<string[]>([])

  const categories = [
    { id: 'all', name: 'Todos', icon: '📚', color: 'bg-gray-500' },
    { id: 'alcohol', name: 'Álcool', icon: '🍺', color: 'bg-amber-500' },
    { id: 'drugs', name: 'Drogas', icon: '💊', color: 'bg-red-500' },
    { id: 'prevention', name: 'Prevenção', icon: '🛡️', color: 'bg-green-500' },
    { id: 'health', name: 'Saúde', icon: '❤️', color: 'bg-pink-500' }
  ]

  const educationalContent: EducationalContent[] = [
    {
      id: '1',
      title: 'Os Efeitos do Álcool no Cérebro Adolescente',
      description: 'Compreenda como o álcool afeta especificamente o desenvolvimento cerebral dos jovens.',
      category: 'alcohol',
      type: 'article',
      duration: 8,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg',
      completed: false,
      rating: 4.8,
      author: 'Dr. Maria Silva',
      publishedAt: '2024-01-15',
      tags: ['neurociência', 'adolescência', 'desenvolvimento'],
      content: `
        <h2>Introdução</h2>
        <p>O cérebro adolescente está em constante desenvolvimento até aproximadamente os 25 anos. Durante este período crítico, o consumo de álcool pode ter consequências duradouras e significativas.</p>
        
        <h3>Como o Álcool Afeta o Cérebro</h3>
        <p>O álcool é um depressor do sistema nervoso central que interfere na comunicação entre neurônios. No cérebro adolescente, isso pode:</p>
        <ul>
          <li>Prejudicar o desenvolvimento do córtex pré-frontal</li>
          <li>Afetar a tomada de decisões</li>
          <li>Interferir na formação da memória</li>
          <li>Reduzir a capacidade de aprendizado</li>
        </ul>
        
        <h3>Consequências a Longo Prazo</h3>
        <p>Estudos mostram que adolescentes que consomem álcool regularmente podem apresentar:</p>
        <ul>
          <li>Menor volume de massa cinzenta</li>
          <li>Problemas de memória persistentes</li>
          <li>Dificuldades de concentração</li>
          <li>Maior risco de dependência na vida adulta</li>
        </ul>
        
        <h3>Prevenção e Conscientização</h3>
        <p>A educação é fundamental. Compreender esses riscos ajuda os jovens a tomar decisões mais informadas sobre o consumo de álcool.</p>
      `
    },
    {
      id: '2',
      title: 'Drogas Sintéticas: Riscos e Consequências',
      description: 'Uma análise completa sobre as drogas sintéticas mais comuns e seus perigos.',
      category: 'drugs',
      type: 'video',
      duration: 12,
      difficulty: 'intermediate',
      thumbnail: 'https://images.pexels.com/photos/3683074/pexels-photo-3683074.jpeg',
      videoUrl: 'https://example.com/video1',
      completed: false,
      rating: 4.9,
      author: 'Prof. João Santos',
      publishedAt: '2024-01-10',
      tags: ['drogas sintéticas', 'riscos', 'química']
    },
    {
      id: '3',
      title: 'Estratégias de Prevenção Eficazes',
      description: 'Técnicas comprovadas para resistir à pressão social e tomar decisões saudáveis.',
      category: 'prevention',
      type: 'infographic',
      duration: 5,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/3825463/pexels-photo-3825463.jpeg',
      completed: false,
      rating: 4.7,
      author: 'Equipe ZeroGrau',
      publishedAt: '2024-01-20',
      tags: ['prevenção', 'pressão social', 'decisões']
    },
    {
      id: '4',
      title: 'Sinais de Dependência: Como Identificar',
      description: 'Aprenda a reconhecer os primeiros sinais de dependência química.',
      category: 'health',
      type: 'article',
      duration: 10,
      difficulty: 'intermediate',
      thumbnail: 'https://images.pexels.com/photos/3985163/pexels-photo-3985163.jpeg',
      completed: false,
      rating: 4.6,
      author: 'Dra. Ana Costa',
      publishedAt: '2024-01-08',
      tags: ['dependência', 'sinais', 'saúde mental']
    },
    {
      id: '5',
      title: 'Mitos e Verdades sobre o Álcool',
      description: 'Desmistificando conceitos errôneos sobre o consumo de álcool.',
      category: 'alcohol',
      type: 'video',
      duration: 15,
      difficulty: 'beginner',
      thumbnail: 'https://images.pexels.com/photos/5699456/pexels-photo-5699456.jpeg',
      videoUrl: 'https://example.com/video2',
      completed: false,
      rating: 4.5,
      author: 'Dr. Carlos Lima',
      publishedAt: '2024-01-12',
      tags: ['mitos', 'verdades', 'educação']
    }
  ]

  const filteredContent = selectedCategory === 'all' 
    ? educationalContent 
    : educationalContent.filter(content => content.category === selectedCategory)

  const handleContentClick = (content: EducationalContent) => {
    setSelectedContent(content)
    
    // Simular conclusão do conteúdo
    setTimeout(() => {
      if (!content.completed) {
        // Adicionar experiência
        addExperience(50)
        
        // Atualizar estatísticas
        const newStats = {
          articlesRead: userStats.articlesRead + (content.type === 'article' ? 1 : 0),
          videosWatched: userStats.videosWatched + (content.type === 'video' ? 1 : 0),
          educationProgress: Math.min(userStats.educationProgress + 10, 100),
          totalTimeSpent: userStats.totalTimeSpent + content.duration
        }
        updateStats(newStats)
        
        // Verificar conquistas
        if (userStats.articlesRead === 0 && content.type === 'article') {
          unlockAchievement('first_article')
          const achievement = userStats.achievements.find(a => a.id === 'first_article')
          if (achievement) setAchievementToShow(achievement)
        }
        
        if (newStats.videosWatched >= 10) {
          unlockAchievement('video_watcher')
        }
        
        if (newStats.educationProgress >= 100) {
          unlockAchievement('education_master')
        }
        
        // Marcar como concluído
        content.completed = true
      }
    }, content.duration * 1000) // Simular tempo de leitura/visualização
  }

  const toggleBookmark = (contentId: string) => {
    setBookmarkedItems(prev => 
      prev.includes(contentId) 
        ? prev.filter(id => id !== contentId)
        : [...prev, contentId]
    )
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-800'
      case 'intermediate': return 'bg-yellow-100 text-yellow-800'
      case 'advanced': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'article': return <BookOpen size={16} />
      case 'video': return <Play size={16} />
      case 'infographic': return <TrendingUp size={16} />
      default: return <BookOpen size={16} />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 pb-24 pt-4">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-6 py-6"
      >
        <div className="text-center">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg"
          >
            <BookOpen size={32} className="text-white" />
          </motion.div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Educação</h1>
          <p className="text-gray-600">Conteúdo científico e acessível sobre prevenção</p>
        </div>

        {/* Progress Summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 bg-white rounded-2xl shadow-lg p-4"
        >
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-gray-800">Seu Progresso</h3>
            <span className="text-2xl">📈</span>
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-blue-600">{userStats.articlesRead}</div>
              <div className="text-xs text-gray-600">Artigos Lidos</div>
            </div>
            <div>
              <div className="text-xl font-bold text-purple-600">{userStats.videosWatched}</div>
              <div className="text-xs text-gray-600">Vídeos Assistidos</div>
            </div>
            <div>
              <div className="text-xl font-bold text-green-600">{userStats.educationProgress}%</div>
              <div className="text-xs text-gray-600">Progresso Total</div>
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* Categories */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
        className="px-6 mb-6"
      >
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                selectedCategory === category.id
                  ? `${category.color} text-white shadow-lg`
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-gray-300'
              }`}
            >
              <span>{category.icon}</span>
              <span className="text-sm font-medium">{category.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Content Grid */}
      <div className="px-6">
        <div className="grid gap-4">
          {filteredContent.map((content, index) => (
            <motion.div
              key={content.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100"
            >
              <div className="relative">
                <img
                  src={content.thumbnail}
                  alt={content.title}
                  className="w-full h-48 object-cover"
                />
                
                {/* Overlay com informações */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                
                {/* Status badges */}
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(content.difficulty)}`}>
                    {content.difficulty}
                  </span>
                  {content.completed && (
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-500 text-white flex items-center gap-1">
                      <CheckCircle size={12} />
                      Concluído
                    </span>
                  )}
                </div>

                {/* Action buttons */}
                <div className="absolute top-3 right-3 flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleBookmark(content.id)
                    }}
                    className={`p-2 rounded-full ${
                      bookmarkedItems.includes(content.id)
                        ? 'bg-yellow-500 text-white'
                        : 'bg-white/80 text-gray-600'
                    }`}
                  >
                    <Bookmark size={16} />
                  </motion.button>
                  
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 rounded-full bg-white/80 text-gray-600"
                  >
                    <Share2 size={16} />
                  </motion.button>
                </div>

                {/* Type and duration */}
                <div className="absolute bottom-3 left-3 flex items-center gap-2 text-white">
                  {getTypeIcon(content.type)}
                  <span className="text-sm font-medium flex items-center gap-1">
                    <Clock size={12} />
                    {content.duration} min
                  </span>
                </div>

                {/* Rating */}
                <div className="absolute bottom-3 right-3 flex items-center gap-1 text-white">
                  <Star size={12} className="fill-current" />
                  <span className="text-sm font-medium">{content.rating}</span>
                </div>
              </div>

              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <User size={14} className="text-gray-500" />
                  <span className="text-sm text-gray-600">{content.author}</span>
                  <span className="text-sm text-gray-400">•</span>
                  <span className="text-sm text-gray-600">{content.publishedAt}</span>
                </div>

                <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2">
                  {content.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {content.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {content.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleContentClick(content)}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:shadow-lg transition-all"
                >
                  {content.completed ? (
                    <>
                      <CheckCircle size={20} />
                      Revisar Conteúdo
                    </>
                  ) : (
                    <>
                      {getTypeIcon(content.type)}
                      {content.type === 'video' ? 'Assistir' : 'Ler'} Agora
                    </>
                  )}
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Content Modal */}
      {selectedContent && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedContent(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-800">{selectedContent.title}</h2>
                <button
                  onClick={() => setSelectedContent(null)}
                  className="p-2 rounded-full bg-gray-100 hover:bg-gray-200"
                >
                  ✕
                </button>
              </div>
              
              {selectedContent.type === 'article' && selectedContent.content && (
                <div
                  className="prose prose-sm max-w-none text-gray-700"
                  dangerouslySetInnerHTML={{ __html: selectedContent.content }}
                />
              )}
              
              {selectedContent.type === 'video' && (
                <div className="text-center py-8">
                  <Play size={48} className="text-blue-500 mx-auto mb-4" />
                  <p className="text-gray-600">Vídeo carregando...</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Duração: {selectedContent.duration} minutos
                  </p>
                </div>
              )}
              
              {selectedContent.type === 'infographic' && (
                <div className="text-center py-8">
                  <TrendingUp size={48} className="text-green-500 mx-auto mb-4" />
                  <p className="text-gray-600">Infográfico interativo carregando...</p>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}

      <AchievementPopup
        achievement={achievementToShow}
        onClose={() => setAchievementToShow(null)}
      />
    </div>
  )
}

export default Education
