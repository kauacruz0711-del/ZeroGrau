
import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {Brain, Clock, Trophy, Target, CheckCircle, X, RotateCcw, TrendingUp, Award, Zap} from 'lucide-react'
import { useAppStore } from '../store/useAppStore'
import AchievementPopup from '../components/AchievementPopup'

interface QuizQuestion {
  id: string
  category: 'alcohol' | 'drugs' | 'prevention' | 'health'
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  difficulty: 'easy' | 'medium' | 'hard'
  points: number
}

interface QuizResult {
  score: number
  totalQuestions: number
  correctAnswers: number
  timeSpent: number
  accuracy: number
  category: string
}

const Quiz = () => {
  const { userStats, updateStats, addExperience, unlockAchievement } = useAppStore()
  const [currentQuiz, setCurrentQuiz] = useState<QuizQuestion[]>([])
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [quizStarted, setQuizStarted] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null)
  const [timeLeft, setTimeLeft] = useState(30)
  const [startTime, setStartTime] = useState<number>(0)
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([])
  const [achievementToShow, setAchievementToShow] = useState<any>(null)
  const [selectedCategory, setSelectedCategory] = useState<string>('mixed')

  const categories = [
    { id: 'mixed', name: 'Misto', icon: '🎯', color: 'from-purple-500 to-indigo-600' },
    { id: 'alcohol', name: 'Álcool', icon: '🍺', color: 'from-amber-500 to-orange-600' },
    { id: 'drugs', name: 'Drogas', icon: '💊', color: 'from-red-500 to-pink-600' },
    { id: 'prevention', name: 'Prevenção', icon: '🛡️', color: 'from-green-500 to-emerald-600' },
    { id: 'health', name: 'Saúde', icon: '❤️', color: 'from-pink-500 to-rose-600' }
  ]

  const allQuestions: QuizQuestion[] = [
    {
      id: '1',
      category: 'alcohol',
      question: 'Qual é a concentração de álcool no sangue considerada legalmente embriagada no Brasil?',
      options: ['0,05 mg/L', '0,1 mg/L', '0,2 mg/L', 'Qualquer concentração'],
      correctAnswer: 3,
      explanation: 'No Brasil, a Lei Seca estabelece tolerância zero para álcool ao dirigir. Qualquer concentração detectada é considerada infração.',
      difficulty: 'medium',
      points: 15
    },
    {
      id: '2',
      category: 'drugs',
      question: 'Qual dessas substâncias é considerada a "droga de entrada" mais comum?',
      options: ['Maconha', 'Cocaína', 'Álcool', 'Cigarro'],
      correctAnswer: 2,
      explanation: 'Estudos mostram que o álcool é frequentemente a primeira substância psicoativa experimentada por jovens, precedendo outras drogas.',
      difficulty: 'easy',
      points: 10
    },
    {
      id: '3',
      category: 'prevention',
      question: 'Qual é a estratégia mais eficaz para recusar drogas em uma festa?',
      options: [
        'Inventar uma desculpa médica',
        'Ser direto e dizer "não, obrigado"',
        'Fingir que vai aceitar depois',
        'Sair da festa imediatamente'
      ],
      correctAnswer: 1,
      explanation: 'Ser direto e educado é a melhor estratégia. Não requer mentiras e demonstra autoconfiança e determinação.',
      difficulty: 'easy',
      points: 10
    },
    {
      id: '4',
      category: 'health',
      question: 'Quanto tempo o álcool permanece no organismo após o consumo?',
      options: ['1-2 horas', '4-6 horas', '8-12 horas', '24-48 horas'],
      correctAnswer: 2,
      explanation: 'O álcool é metabolizado pelo fígado a uma taxa de aproximadamente uma dose por hora, mas pode ser detectado por 8-12 horas.',
      difficulty: 'medium',
      points: 15
    },
    {
      id: '5',
      category: 'alcohol',
      question: 'Qual parte do cérebro é mais afetada pelo consumo de álcool em adolescentes?',
      options: ['Cerebelo', 'Córtex pré-frontal', 'Hipocampo', 'Tronco cerebral'],
      correctAnswer: 1,
      explanation: 'O córtex pré-frontal, responsável por tomada de decisões e controle de impulsos, é severamente afetado pelo álcool em cérebros em desenvolvimento.',
      difficulty: 'hard',
      points: 20
    },
    {
      id: '6',
      category: 'drugs',
      question: 'Qual é o principal componente ativo da maconha?',
      options: ['CBD', 'THC', 'Nicotina', 'Cafeína'],
      correctAnswer: 1,
      explanation: 'O THC (Tetraidrocanabinol) é o principal componente psicoativo da maconha, responsável pelos efeitos de alteração da consciência.',
      difficulty: 'medium',
      points: 15
    },
    {
      id: '7',
      category: 'prevention',
      question: 'Qual fator é mais importante na prevenção do uso de drogas?',
      options: [
        'Punições severas',
        'Educação e informação',
        'Isolamento social',
        'Proibição total'
      ],
      correctAnswer: 1,
      explanation: 'A educação baseada em evidências é o método mais eficaz de prevenção, permitindo decisões informadas e conscientes.',
      difficulty: 'easy',
      points: 10
    },
    {
      id: '8',
      category: 'health',
      question: 'Qual é o principal risco do uso de drogas sintéticas?',
      options: [
        'Vício imediato',
        'Composição desconhecida',
        'Preço elevado',
        'Detecção em exames'
      ],
      correctAnswer: 1,
      explanation: 'Drogas sintéticas frequentemente têm composição desconhecida e variável, tornando impossível prever seus efeitos e riscos.',
      difficulty: 'hard',
      points: 20
    }
  ]

  useEffect(() => {
    if (quizStarted && !quizCompleted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !showExplanation) {
      handleAnswerSubmit()
    }
  }, [timeLeft, quizStarted, quizCompleted, showExplanation])

  const startQuiz = (category: string) => {
    let questionsToUse = allQuestions
    if (category !== 'mixed') {
      questionsToUse = allQuestions.filter(q => q.category === category)
    }
    
    // Embaralhar e pegar 5 questões
    const shuffled = [...questionsToUse].sort(() => Math.random() - 0.5).slice(0, 5)
    
    setCurrentQuiz(shuffled)
    setCurrentQuestionIndex(0)
    setSelectedAnswer(null)
    setShowExplanation(false)
    setQuizStarted(true)
    setQuizCompleted(false)
    setTimeLeft(30)
    setStartTime(Date.now())
    setUserAnswers(new Array(shuffled.length).fill(null))
  }

  const handleAnswerSelect = (answerIndex: number) => {
    if (!showExplanation) {
      setSelectedAnswer(answerIndex)
    }
  }

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null && timeLeft > 0) return
    
    const newAnswers = [...userAnswers]
    newAnswers[currentQuestionIndex] = selectedAnswer
    setUserAnswers(newAnswers)
    setShowExplanation(true)
  }

  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentQuiz.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
      setSelectedAnswer(null)
      setShowExplanation(false)
      setTimeLeft(30)
    } else {
      finishQuiz()
    }
  }

  const finishQuiz = () => {
    const endTime = Date.now()
    const totalTime = Math.round((endTime - startTime) / 1000)
    
    let score = 0
    let correctCount = 0
    
    userAnswers.forEach((answer, index) => {
      if (answer === currentQuiz[index].correctAnswer) {
        score += currentQuiz[index].points
        correctCount++
      }
    })
    
    const accuracy = Math.round((correctCount / currentQuiz.length) * 100)
    
    const result: QuizResult = {
      score,
      totalQuestions: currentQuiz.length,
      correctAnswers: correctCount,
      timeSpent: totalTime,
      accuracy,
      category: selectedCategory
    }
    
    setQuizResult(result)
    setQuizCompleted(true)
    
    // Atualizar estatísticas
    const newStats = {
      quizzesCompleted: userStats.quizzesCompleted + 1,
      quizAccuracy: Math.round(((userStats.quizAccuracy * userStats.quizzesCompleted) + accuracy) / (userStats.quizzesCompleted + 1)),
      totalTimeSpent: userStats.totalTimeSpent + Math.round(totalTime / 60)
    }
    updateStats(newStats)
    
    // Adicionar experiência
    addExperience(score)
    
    // Verificar conquistas
    if (userStats.quizzesCompleted === 0) {
      unlockAchievement('first_quiz')
      const achievement = userStats.achievements.find(a => a.id === 'first_quiz')
      if (achievement) setAchievementToShow(achievement)
    }
    
    if (accuracy === 100) {
      unlockAchievement('quiz_perfectionist')
      const achievement = userStats.achievements.find(a => a.id === 'quiz_perfectionist')
      if (achievement) setAchievementToShow(achievement)
    }
    
    if (newStats.quizzesCompleted >= 50) {
      unlockAchievement('quiz_marathon')
    }
  }

  const resetQuiz = () => {
    setQuizStarted(false)
    setQuizCompleted(false)
    setCurrentQuestionIndex(0)
    setSelectedAnswer(null)
    setShowExplanation(false)
    setQuizResult(null)
    setUserAnswers([])
  }

  const currentQuestion = currentQuiz[currentQuestionIndex]

  if (!quizStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 pb-24 pt-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-6 py-6"
        >
          <div className="text-center">
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg"
            >
              <Brain size={32} className="text-white" />
            </motion.div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Quiz Interativo</h1>
            <p className="text-gray-600">Teste seus conhecimentos sobre prevenção</p>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="px-6 mb-6"
        >
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Trophy className="text-yellow-500" />
              Suas Estatísticas
            </h3>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{userStats.quizzesCompleted}</div>
                <div className="text-xs text-gray-600">Quizzes Feitos</div>
              </div>
              
              <div className="text-center p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{userStats.quizAccuracy}%</div>
                <div className="text-xs text-gray-600">Precisão Média</div>
              </div>
              
              <div className="text-center p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-yellow-600">{userStats.level}</div>
                <div className="text-xs text-gray-600">Nível Atual</div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Category Selection */}
        <div className="px-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Escolha uma Categoria</h2>
          
          <div className="grid gap-3">
            {categories.map((category, index) => (
              <motion.button
                key={category.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setSelectedCategory(category.id)
                  startQuiz(category.id)
                }}
                className={`p-4 rounded-2xl text-white font-semibold shadow-lg bg-gradient-to-r ${category.color} hover:shadow-xl transition-all`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{category.icon}</span>
                    <div className="text-left">
                      <h3 className="text-lg font-bold">{category.name}</h3>
                      <p className="text-sm opacity-90">
                        {category.id === 'mixed' ? 'Perguntas variadas' : `Foque em ${category.name.toLowerCase()}`}
                      </p>
                    </div>
                  </div>
                  <Zap size={24} className="opacity-75" />
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (quizCompleted && quizResult) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 pb-24 pt-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="px-6 py-6"
        >
          <div className="bg-white rounded-2xl shadow-2xl p-8 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Trophy size={40} className="text-white" />
            </motion.div>

            <h1 className="text-3xl font-bold text-gray-800 mb-2">Quiz Concluído!</h1>
            <p className="text-gray-600 mb-6">Confira seus resultados</p>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                <div className="text-2xl font-bold text-blue-600">{quizResult.score}</div>
                <div className="text-sm text-gray-600">Pontos</div>
              </div>
              
              <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl">
                <div className="text-2xl font-bold text-green-600">{quizResult.accuracy}%</div>
                <div className="text-sm text-gray-600">Precisão</div>
              </div>
              
              <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl">
                <div className="text-2xl font-bold text-yellow-600">{quizResult.correctAnswers}/{quizResult.totalQuestions}</div>
                <div className="text-sm text-gray-600">Acertos</div>
              </div>
              
              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
                <div className="text-2xl font-bold text-purple-600">{quizResult.timeSpent}s</div>
                <div className="text-sm text-gray-600">Tempo</div>
              </div>
            </div>

            <div className="space-y-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={resetQuiz}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-600 text-white py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all"
              >
                Fazer Outro Quiz
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => window.history.back()}
                className="w-full bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-200 transition-all"
              >
                Voltar ao Início
              </motion.button>
            </div>
          </div>
        </motion.div>

        <AchievementPopup
          achievement={achievementToShow}
          onClose={() => setAchievementToShow(null)}
        />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 pb-24 pt-4">
      {/* Header com progresso */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-6 py-4"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Brain className="text-purple-600" size={24} />
            <div>
              <h1 className="text-lg font-bold text-gray-800">
                Pergunta {currentQuestionIndex + 1} de {currentQuiz.length}
              </h1>
              <p className="text-sm text-gray-600">Categoria: {currentQuestion?.category}</p>
            </div>
          </div>
          
          <div className="text-right">
            <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-blue-600'}`}>
              {timeLeft}s
            </div>
            <div className="text-xs text-gray-600">restantes</div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-gray-200 rounded-full h-2">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${((currentQuestionIndex + 1) / currentQuiz.length) * 100}%` }}
            className="bg-gradient-to-r from-purple-500 to-blue-600 h-2 rounded-full transition-all duration-500"
          />
        </div>
      </motion.div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          className="px-6"
        >
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <div className="flex items-center gap-2 mb-4">
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                currentQuestion?.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                currentQuestion?.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                {currentQuestion?.difficulty}
              </span>
              <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                {currentQuestion?.points} pontos
              </span>
            </div>

            <h2 className="text-xl font-bold text-gray-800 mb-6 leading-relaxed">
              {currentQuestion?.question}
            </h2>

            <div className="space-y-3">
              {currentQuestion?.options.map((option, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => handleAnswerSelect(index)}
                  disabled={showExplanation}
                  className={`w-full p-4 text-left rounded-xl border-2 transition-all ${
                    selectedAnswer === index
                      ? showExplanation
                        ? index === currentQuestion.correctAnswer
                          ? 'border-green-500 bg-green-50 text-green-800'
                          : 'border-red-500 bg-red-50 text-red-800'
                        : 'border-blue-500 bg-blue-50 text-blue-800'
                      : showExplanation && index === currentQuestion.correctAnswer
                        ? 'border-green-500 bg-green-50 text-green-800'
                        : 'border-gray-200 bg-gray-50 text-gray-700 hover:border-gray-300 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      selectedAnswer === index
                        ? showExplanation
                          ? index === currentQuestion.correctAnswer
                            ? 'border-green-500 bg-green-500'
                            : 'border-red-500 bg-red-500'
                          : 'border-blue-500 bg-blue-500'
                        : showExplanation && index === currentQuestion.correctAnswer
                          ? 'border-green-500 bg-green-500'
                          : 'border-gray-300'
                    }`}>
                      {showExplanation && (
                        <>
                          {index === currentQuestion.correctAnswer ? (
                            <CheckCircle size={14} className="text-white" />
                          ) : selectedAnswer === index ? (
                            <X size={14} className="text-white" />
                          ) : null}
                        </>
                      )}
                    </div>
                    <span className="font-medium">{option}</span>
                  </div>
                </motion.button>
              ))}
            </div>

            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-200"
              >
                <h3 className="font-semibold text-blue-800 mb-2">Explicação:</h3>
                <p className="text-blue-700 text-sm leading-relaxed">
                  {currentQuestion?.explanation}
                </p>
              </motion.div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            {!showExplanation ? (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleAnswerSubmit}
                disabled={selectedAnswer === null}
                className={`flex-1 py-4 rounded-xl font-semibold transition-all ${
                  selectedAnswer !== null
                    ? 'bg-gradient-to-r from-purple-500 to-blue-600 text-white shadow-lg hover:shadow-xl'
                    : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                }`}
              >
                Confirmar Resposta
              </motion.button>
            ) : (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleNextQuestion}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all"
              >
                {currentQuestionIndex < currentQuiz.length - 1 ? 'Próxima Pergunta' : 'Finalizar Quiz'}
              </motion.button>
            )}
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={resetQuiz}
              className="p-4 bg-gray-100 text-gray-600 rounded-xl hover:bg-gray-200 transition-all"
            >
              <RotateCcw size={20} />
            </motion.button>
          </div>
        </motion.div>
      </AnimatePresence>

      <AchievementPopup
        achievement={achievementToShow}
        onClose={() => setAchievementToShow(null)}
      />
    </div>
  )
}

export default Quiz
